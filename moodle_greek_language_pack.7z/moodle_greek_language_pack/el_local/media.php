<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage media
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['flashanimation'] = 'Flash animation';
$string['flashanimation_desc'] = 'Αρχεία με επέκταση *.swf. Για λόγους ασφαλείας αυτός ο τύπος αρχείου είναι μόνο ενσωματωμένο μέσα σε αξιόπιστο κείμενο.';
$string['flashvideo'] = 'Flash video';
$string['flashvideo_desc'] = 'Αρχεία με επέκταση *.flv και *.f4v. Παίζουν video χρησιμοποιώντας Flowplayer, το οποίο απαιτεί το πρόσθετο του Flash και javascript.';
$string['html5audio'] = 'HTML 5 audio';
$string['html5audio_desc'] = 'Αρχεία ήχου με επεκτάσεις *.ogg, *.aac και *.mp3. Χρησιμοποιείται κυρίως για κινητές συσκευές. (Η μορφή εξαρτάται από τον φυλλομετρητή).';
$string['html5video'] = 'HTML 5 video';
$string['html5video_desc'] = 'Αρχεία video με επεκτάσεις *.webm, *.m4v, *.ogv, *.mp4 και άλλα. Χρησιμοποιείται κυρίως για κινητές συσκευές. (Η μορφή εξαρτάται από τον φυλλομετρητή).';
$string['legacyheading'] = 'Legacy media players';
$string['legacyheading_desc'] = 'Αυτοί οι players δεν χρησιμοποιούνται συχνά στο διαδίκτυο και απαιτούν πρόσθετα στον φυλλομετρητή τα οποία δεν είναι κοινά διαδεδομένα.';
$string['legacyquicktime'] = 'QuickTime player';
$string['legacyquicktime_desc'] = 'Αρχεία με επεκτάσεις *.mov, *.mp4, *.m4a, *.mp4 και *.mpg. Χρειάζεται τον QuickTime player ή κωδικοποιητές.';
$string['legacyreal'] = 'Real media player';
$string['legacyreal_desc'] = 'Αρχεία με επεκτάσεις *.rm, *.ra, *.ram, *.rp και *.rv. Χρειάζεται τον RealPlayer.';
$string['legacywmp'] = 'Windows media player';
$string['legacywmp_desc'] = 'Αρχεία με επεκτάσεις *.avi και *.wmv. Είναι πλήρως συμβατός με Internet Explorer στα Windows, μπορεί να μην δουλεύει με άλλους φυλλομετρητές ή λειτουργικά συστήματα.';
$string['mediaformats'] = 'Διαθέσιμοι players';
$string['mediaformats_desc'] = 'Όταν οι players ενεργοποιηθούν σε αυτές τις ρυθμίσεις, τα αρχεία μπορούν να ενσωματωθούν με τη χρήση του φίλτρου για τα media (αν έχει ενεργοποιηθεί) ή χρησιμοποιώντας ένα αρχείο ή URL με την επιλογή Ενσωμάτωση. Όταν δεν είναι ενεργοποιημένη η επιλογή, τα αρχεία αυτά δεν ενσωματώνονται και οι χρήστες μπορούν να κατεβάσουν ή να ακολουθήσουν τις συνδέσεις σε αυτούς τους πόρους. Όταν δύο players υποστηρίζουν το ίδιο format, η ενεργοποίηση και των 2, αυξάνει τη συμβατότητα μεταξύ διαφόρων συσκευών, όπως τα κινητά τηλέφωνα. Είναι δυνατό να αυξηθεί περαιτέρω η συμβατότητα με την παροχή πολλαπλών αρχείων σε διαφορετικές μορφές για ένα κλιπ ήχου ή βίντεο.';
$string['mediasettings'] = 'Ενσωμάτωση Media';
$string['mp3audio'] = 'MP3 audio';
$string['mp3audio_desc'] = 'Αρχεία με επεκτάσεις *.mp3. Παίζει ήχο χρησιμοποιώντας Flowplayer, το οποίο απαιτεί το πρόσθετο του Flash.';
$string['sitevimeo'] = 'Vimeo';
$string['sitevimeo_desc'] = 'Site Vimeo, διαμοιρασμού video.';
$string['siteyoutube'] = 'YouTube';
$string['siteyoutube_desc'] = 'Site YouTube, διαμοιρασμού video, υποστηρίζει βίντεο και συνδέσμους playlist.';
