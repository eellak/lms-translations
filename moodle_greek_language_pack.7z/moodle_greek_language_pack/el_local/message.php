<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage message
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['blockedusers'] = 'Φραγμένοι χρήστες ({$a})';
$string['enabled'] = 'Ενεργοποιημένο';
$string['errortranslatingdefault'] = 'Παρουσιάστηκε σφάλμα κατά τη μετάφραση της προεπιλεγμένης ρύθμισης που προβλέπεται από το plugin. Θα χρησιμοποιηθούν οι προεπιλογές του συστήματος.';
$string['errorwhilesendingmessage'] = 'Παρουσιάστηκε σφάλμα κατά την αποστολή του μηνύματος, παρακαλώ δοκιμάστε ξανά αργότερα.';
$string['eventmessagecontactadded'] = 'Προστέθηκε η επαφή μηνύματος';
$string['eventmessagecontactblocked'] = 'Η επαφή μηνύματος αποκλείστηκε';
$string['eventmessagecontactremoved'] = 'Η επαφή μηνύματος αφαιρέθηκε';
$string['eventmessagecontactunblocked'] = 'Η επαφή μηνύματος επιτράπηκε';
$string['eventmessagesent'] = 'Το μήνυμα στάλθηκε';
$string['eventmessageviewed'] = 'Προβολή μηνύματος';
$string['gotomessages'] = 'Μετάβαση στα μηνύματα';
$string['keywordssearchresultstoomany'] = 'Βρέθηκαν περισσότερα από {$a} μηνύματα.  Βελτιώστε την αναζήτησή σας.';
$string['managecontacts'] = 'Διαχείριση των επαφών μου';
$string['messagehistoryfull'] = '\'Όλα τα μηνύματα';
$string['messagenavigation'] = 'Πλοήγηση μηνύματος';
$string['messagesent'] = 'Το μήνυμα στάλθηκε';
$string['messagetosend'] = 'Μήνυμα προς αποστολή';
$string['messagingblockednoncontact'] = '{$a} δεν θα μπορέσει να σας απαντήσει, καθώς έχετε αποκλείσει τους χρήστες που δεν έχετε σαν επαφές';
$string['mostrecent'] = 'Πρόσφατα μηνύματα';
$string['noreply'] = 'Μην απαντήσετε σε αυτό το μήνυμα';
$string['outputdisabled'] = 'Απενεργοποιημένη έξοδος';
$string['outputdoesnotexist'] = 'Δεν υπάρχει έξοδος μηνύματος';
$string['outputnotavailable'] = 'Μη διαθέσιμο';
$string['page-message-x'] = 'Όλες οι σελίδες μηνύματος';
$string['recent'] = 'Πρόσφατο';
$string['sendingmessage'] = 'Αποστολή μηνύματος';
$string['sendingvia'] = 'Αποστολή "{$a->provider}" μέσω "{$a->processor}"';
$string['sendingviawhen'] = 'Αποστολή "{$a->provider}" μέσω "{$a->processor}" ενώ {$a->state}';
$string['thisconversation'] = 'αυτή η συζήτηση';
$string['touserdoesntexist'] = 'Δεν μπορείτε να στείλετε μήνυμα σε μια ταυτότητα χρήστη ({$a}) που δεν υπάρχει';
$string['unreadnewmessage'] = 'Νέο αδιάβαστο μήνυμα από {$a}';
$string['viewconversation'] = 'Προβολή συζήτησης';
