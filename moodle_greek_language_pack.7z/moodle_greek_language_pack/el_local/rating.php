<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage rating
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allowratings'] = 'Μπορούν να αξιολογηθούν τα στοιχεία;';
$string['allratingsforitem'] = 'Όλες οι υποβληθείσες αξιολογήσεις';
$string['couldnotdeleteratings'] = 'Δυστυχώς, αυτό δεν μπορεί να διαγραφεί, καθώς έχει ήδη αξιολογηθεί.';
$string['norate'] = 'Δεν επιτρέπεται η αξιολόγηση των στοιχείων!';
$string['noratings'] = 'Δεν έχουν υποβληθεί αξιολογήσεις';
$string['noviewanyrate'] = 'Μπορείτε μόνο να δείτε τα αποτελέσματα για τα στοιχεία που έχετε φτιάξει';
$string['noviewrate'] = 'Δεν έχετε τη δυνατότητα να δείτε τις αξιολογήσεις του στοιχείου';
$string['rate'] = 'Βαθμός';
$string['ratepermissiondenied'] = 'Δεν έχετε δικαίωμα να βαθμολογήσετε αυτό το στοιχείο';
$string['rating'] = 'Βαθμός';
$string['ratinginvalid'] = 'Ο βαθμός είναι άκυρος';
$string['rolewarning_help'] = 'Για την υποβολή αξιολογήσεων οι χρήστες χρειάζονται την moodle / βαθμολογία: δυνατότητα βαθμολόγησης και συγκεκριμένες δυνατότητες σε κάθε ενότητα. Οι χρήστες στους οποίους έχουν ανατεθεί οι παρακάτω ρόλοι πρέπει να είναι σε θέση να αξιολογήσουν τα στοιχεία. Ο κατάλογος των ρόλων μπορεί να τροποποιηθεί μέσω του συνδέσμου δικαιώματα στο μπλοκ διαχείριση.';
$string['scaleselectionrequired'] = 'Κατά την επιλογή ενός συγκεντρωτικού τύπου αξιολόγησης θα πρέπει να επιλέξετε να χρησιμοποιήσετε είτε μια κλίμακα ή να ορίσετε μια μέγιστη τιμή βαθμών.';

