<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage portfolio
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['callbackclassinvalid'] = 'Η επανάκληση της κλάσης που προσδιορίστηκε ήταν άκυρη ή μη μέρος της ιεραρχίας portfolio_caller';
$string['confirmcancel'] = 'Είστε σίγουροι ότι θέλετε να ακυρώσετε αυτή την εξαγωγή;';
$string['exportalreadyfinished'] = 'Η εξαγωγή του χαρτοφυλακίου ολοκληρώθηκε!';
$string['exportalreadyfinisheddesc'] = 'Η εξαγωγή του χαρτοφυλακίου ολοκληρώθηκε!';
$string['exportingcontentfrom'] = 'Εξαγωγή περιεχομένου από {$a}';
$string['exportingcontentto'] = 'Εξαγωγή περιεχομένου στο {$a}';
$string['fileoutputnotsupported'] = 'Η επανασυγγραφή του αρχείου εξόδου δεν υποστηρίζεται για αυτή τη μορφή';
$string['format_document'] = 'Έγγραφο';
$string['format_leap2a'] = 'Μορφή χαρτοφυλακίου Leap2A';
$string['format_pdf'] = 'PDF';
$string['format_plainhtml'] = 'HTML';
$string['format_presentation'] = 'Παρουσίαση';
$string['format_spreadsheet'] = 'Υπολογιστικό φύλλο';
$string['leap2a_emptyselection'] = 'Δεν έχει επιλεχθεί η απαιτούμενη τιμή';
$string['leap2a_entryalreadyexists'] = 'Προσπαθήσατε να προσθέσετε μια εγγραφή Leap2A με κωδικό ({$a}) ο οποίος υπάρχει ήδη σε αυτό το feed.';
$string['leap2a_feedtitle'] = 'Εξαγωγή Leap2A από το Moodle για το {$a}';
$string['leap2a_filecontent'] = 'Έγινε προσπάθεια να εξαχθεί η Leap2A εγγραφή σε αρχείο, αντί να χρησιμοποιηθεί η υποκλάση του αρχείου.';
$string['leap2a_invalidentryfield'] = 'Προσπαθήσετε να θέσετε ένα πεδίο εγγραφής που  δεν υπάρχει ({$a}) ή το οποίο δεν μπορεί να οριστεί απευθείας';
$string['leap2a_invalidentryid'] = 'Προσπαθήσατε να προσπελάσετε μια εγγραφή με κωδικό που δεν υπάρχει ({$a})';
$string['leap2a_missingfield'] = 'Το υποχρεωτικό Leap2A πεδίο {$a} λείπει';
$string['leap2a_nonexistantlink'] = 'Μια Leap2A εγγραφή ({$a->from}) προσπάθησε να συνδεθεί με μια μη υπάρχουσα εγγραφή  ({$a->to}) με {$a->rel}';
$string['leap2a_overwritingselection'] = 'Επανεγγραφή του αρχικού τύπου μιας εγγραφής  ({$a}) με επιλογή στο make_selection';
$string['leap2a_selflink'] = 'Μια Leap2A εγγραφή ({$a->id}) προσπάθησε να συνδεθεί με {$a->rel}';
$string['mimecheckfail'] = 'Το πρόσθετο χαρτοφυλακίου {$a->plugin} δεν υποστηρίζει αυτό το mimetype {$a->mimetype}';
$string['multipleinstancesdisallowed'] = 'Προσπάθεια δημιουργίας ενός ακόμα στιγμιότυπου ενός πρόσθετου το οποίο έχει απαγορεύσει τα πολλαπλά στιγμιότυπα ({$a})';
$string['nocallbackcomponent'] = 'Τα συγκεκριμένα components  {$a} δεν βρέθηκαν.';
$string['noinstanceyet'] = 'Δεν έχει ακόμα επιλεχθεί';
$string['nomultipleexports'] = 'Λυπούμαστε, αλλά ο προορισμός του χαρτοφυλακίου ({$a->plugin}) δεν υποστηρίζει πολλαπλές ταυτόχρονες εξαγωγές. Σας παρακαλώ <a href="{$a->link}"> ολοκληρώστε την τρέχουσα πρώτα </a> και δοκιμάστε ξανά';
$string['singleinstancenomultiallowed'] = 'Μόνο ένα στιγμιότυπο πρόσθετου χαρτοφυλακίου είναι διαθέσιμο, δεν υποστηρίζει πολλαπλές εξαγωγές ανά 
συνεδρία, και υπάρχει ήδη μια ενεργή εξαγωγή στη συνεδρία που χρησιμοποιεί αυτό το πρόσθετο!';

