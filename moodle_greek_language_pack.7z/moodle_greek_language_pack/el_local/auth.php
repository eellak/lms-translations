<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage auth
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actauthhdr'] = 'Ενεργά στοιχεία ταυτοποίησης';
$string['authloginviaemail_desc'] = 'Να επιτρέπεται στους χρήστες να χρησιμοποιούν τόσο το όνομα χρήστη όσο και τη διεύθυνση email (αν είναι μοναδική) για σύνδεση στην ιστοσελίδα.';
$string['auth_invalidnewemailkey'] = 'Σφάλμα: εάν προσπαθείτε να επιβεβαιώσετε κάποια αλλαγή της διεύθυνσης email σας, ενδέχεται να έχετε κάνει κάποιο λάθος στην αντιγραφή URL που σας στείλαμε με email. Παρακαλώ αντιγράψτε τη διεύθυνση και προσπαθήστε ξανά.';
$string['auth_outofnewemailupdateattempts'] = 'Έχετε εξαντλήσει τις επιτρεπόμενες προσπάθειες για να ενημερώσετε τη διεύθυνση email σας. Το αίτημα σας για ενημέρωση έχει ακυρωθεί.';
$string['auth_remove_delete'] = 'Πλήρης διαγραφή.';
$string['auth_remove_keep'] = 'Διατήρηση';
$string['auth_remove_suspend'] = 'Αναστολή';
$string['auth_remove_user'] = 'Καθορίστε τι να κάνει με τον εσωτερικό λογαριασμό χρήστη κατά τη διάρκεια του μαζικού  συγχρονισμού όταν ο χρήστης αφαιρέθηκε από εξωτερική πηγή. Μόνον  οι χρήστες που αναστέλλονται, αναβιώνουν αυτόματα αν επανεμφανιστούν από  εξωτερική πηγή.';
$string['auth_remove_user_key'] = 'Αφαιρέθηκε εξωτερικός χρήστης';
$string['auth_sync_script'] = 'Cron script συγχρονισμού';
$string['auto_add_remote_users'] = 'Αυτόματη προσθήκη των απομακρυσμένων χρηστών';
$string['emailchangecancel'] = 'Ακύρωση αλλαγής email';
$string['emailchangepending'] = 'Αλλαγή σε εκκρεμότητα. Ανοίξτε τον σύνδεσμο που σας στάλθηκε στο {$a->preference_newemail}.';
$string['emailnowexists'] = 'Η διεύθυνση email που προσπαθήσατε να εκχωρήσετε στο προφίλ σας έχει εκχωρηθεί σε κάποιον άλλο από τότε που υποβάλλατε το αρχικό σας αίτημα. Το αίτημα σας για αλλαγή της διεύθυνσης email με το παρόν ακυρώνεται, αλλά μπορείτε να δοκιμάσετε ξανά με μια διαφορετική διεύθυνση.';
$string['emailupdatesuccess'] = 'Η διεύθυνση email του χρήστη  <em>{$a->fullname}</em> ενημερώθηκε με επιτυχία σε <em> {$ a-> email} </ em>.';
$string['emailupdatetitle'] = 'Επιβεβαίωση ενημέρωσης email στο {$a->site}';
$string['enterthenumbersyouhear'] = 'Εισάγετε τους αριθμούς που ακούτε';
$string['enterthewordsabove'] = 'Εισαγάγετε τις παραπάνω λέξεις';
$string['errormaxconsecutiveidentchars'] = 'Οι κωδικοί πρόσβασης πρέπει να έχουν το πολύ {$ a} διαδοχικά πανομοιότυπους χαρακτήρες.';
$string['errorminpassworddigits'] = 'Οι κωδικοί πρόσβασης πρέπει να έχουν τουλάχιστον {$a} ψηφίο(α)';
$string['errorminpasswordlength'] = 'Οι κωδικοί πρόσβασης πρέπει να έχουν τουλάχιστον {$a} αριθμό χαρακτήρων.';
$string['errorminpasswordlower'] = 'Οι κωδικοί πρόσβασης πρέπει να έχουν τουλάχιστον {$a} μικρό(ά) γράμμα(τα).';
$string['errorminpasswordnonalphanum'] = 'Οι κωδικοί πρόσβασης πρέπει να έχουν τουλάχιστον  {$a} μη αλφαριθμητικό(ούς) χαρακτήρα(ες).';
$string['errorminpasswordupper'] = 'Οι κωδικοί πρόσβασης πρέπει να έχουν τουλάχιστον {$a} κεφαλαίο(α) γράμμα(τα).';
$string['errorpasswordreused'] = 'Αυτός ο κωδικός πρόσβασης έχει χρησιμοποιηθεί στο παρελθόν, και δεν επιτρέπεται να επαναχρησιμοποιηθεί.';
$string['errorpasswordupdate'] = 'Σφάλμα κατά την ενημέρωση του κωδικού πρόσβασης, ο κωδικός πρόσβασης δεν άλλαξε';
$string['forgottenpassword'] = 'Εάν εισάγετε μια διεύθυνση URL εδώ, θα χρησιμοποιηθεί ως ο χαμένος κωδικός πρόσβασης σελίδας ανάκτησης για αυτή την ιστοσελίδα. Αυτό προορίζεται για ιστοσελίδες όπου οι κωδικοί πρόσβασης διαχειρίζονται εξ ολοκλήρου εκτός του Moodle. Αφήστε το κενό για να χρησιμοποιήσετε τον προεπιλεγμένο κωδικό πρόσβασης αποκατάστασης.';
$string['forgottenpasswordurl'] = 'URL ανάκτησης κωδικού πρόσβασης';
$string['incorrectpleasetryagain'] = 'Λανθασμένο. Παρακαλώ προσπάθησε ξανά.';
$string['informminpasswordreuselimit'] = 'Οι κωδικοί πρόσβασης μπορούν να επαναχρησιμοποιηθούν μετά από {$ a} αλλαγές';
$string['limitconcurrentlogins'] = 'Όριο ταυτόχρονων συνδέσεων';
$string['limitconcurrentlogins_desc'] = 'Εάν ενεργοποιηθεί ο αριθμός των ταυτόχρονων συνδέσεων του περιηγητή για κάθε χρήστη είναι περιορισμένος. Η παλαιότερη συνεδρία τερματίζεται όταν οι συνδέσεις φτάσουν στο όριο, παρακαλούμε σημειώστε ότι οι χρήστες μπορεί να χάσουν όλες τις μη αποθηκευμένες εργασίες. Αυτή η ρύθμιση δεν είναι συμβατή με στοιχεία μοναδικής πιστοποίησης χρήστη (SSO).';
$string['nopasswordchange'] = 'Ο κωδικός πρόσβασης δεν μπορεί να αλλαχθεί';
$string['nopasswordchangeforced'] = 'Δεν μπορείτε να συνεχίσετε χωρίς να αλλάξετε τον κωδικό πρόσβασής σας, ωστόσο δεν υπάρχει διαθέσιμη σελίδα για την αλλαγή αυτή. Παρακαλούμε επικοινωνήστε με το Moodle διαχειριστή σας.';
$string['ntlmsso_attempting'] = 'Απόπειρα ενιαίας εγγραφής μέσω  NTLM...';
$string['ntlmsso_failed'] = 'Η αυτόματη σύνδεση απέτυχε, δοκιμάστε την κανονική σελίδα σύνδεσης ...';
$string['ntlmsso_isdisabled'] = 'Το NTLM SSO είναι απενεργοποιημένο.';
$string['pluginnotenabled'] = 'Το στοιχείο ελέγχου ταυτότητας \'{$a}\' δεν έχει ενεργοποιηθεί.';
$string['pluginnotinstalled'] = 'Το στοιχείο ελέγχου ταυτότητας \'{$a}\' δεν έχει εγκατασταθεί.';
$string['recaptcha'] = 'reCAPTCHA';
$string['security_question'] = 'Ερώτηση Ασφαλείας';
$string['selfregistration'] = 'Αυτόματη εγγραφή';
$string['selfregistration_help'] = 'Εάν ένα πρόγραμμα ελέγχου ταυτότητας έχει επιλεγεί, όπως η βασιζόμενη σε email  αυτόματη εγγραφή, τότε επιτρέπει στους δυνητικούς χρήστες να εγγραφούν και να δημιουργήσουν λογαριασμούς. Αυτό έχει ως αποτέλεσμα τη δυνατότητα των spammer να δημιουργήσουν λογαριασμούς προκειμένου να χρησιμοποιήσουν δημοσιεύσεις σε φόρουμ,  καταχωρήσεις σε blog κλπ. για spam. Για να αποφευχθεί αυτός ο κίνδυνος, η αυτόματη εγγραφή θα πρέπει να είναι απενεργοποιημένη ή να περιορίζεται από τη ρύθμιση  <em>Allowed email domains</em> .';
$string['sha1'] = 'SHA-1 hash';
$string['suspended_help'] = 'Λογαριασμοί χρηστών που έχουν ανασταλεί δεν μπορούν να συνδεθούν ή να χρησιμοποιήσουν τις υπηρεσίες web, και τυχόν εξερχόμενα μηνύματα απορρίπτονται.';
$string['testsettingsheading'] = 'Δοκιμαστικές ρυθμίσεις ελέγχου ταυτότητας - {$a}';
$string['user_activatenotsupportusertype'] = 'Πιστοποίηση: ldap user_activate() δεν υποστηρίζει τον επιλεγμένο τύπο χρήστη: {$ a}';
$string['user_disablenotsupportusertype'] = 'Πιστοποίηση:  ldap user_disable() δεν υποστηρίζει επιλεγμένο τύπο χρήστη(..ακόμη)';
