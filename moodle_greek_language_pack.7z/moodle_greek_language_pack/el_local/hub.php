<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage hub
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addscreenshots'] = 'Προσθήκη στιγμιότυπου οθόνης';
$string['advertise'] = 'Διαφημίστε αυτό το μάθημα για να εγγραφούν μαθητές';
$string['advertised'] = 'Διαφημιζόμενο';
$string['advertiseon'] = 'Διαφημίστε αυτό το μάθημα σε {$a}';
$string['advertiseonhub'] = 'Διαφημίστε αυτό το μάθημα σε έναν κόμβο (hub)';
$string['advertiseonmoodleorg'] = 'Διαφημίστε αυτό το μάθημα στο  moodle.org';
$string['advertisepublication_help'] = 'Η διαφήμιση του μαθήματός σας σε έναν κοινοτικό κομβικό υπολογιστή, δίνει τη δυνατότητα στον κόσμο, να βρει αυτό το μάθημα και να εγγραφεί σε αυτό.';
$string['all'] = 'Όλα';
$string['allowglobalsearch'] = 'Δημοσίευση αυτού του κόμβου και δυνατότητα αναζήτησης όλων των μαθημάτων';
$string['allowpublicsearch'] = 'Δημοσίευση αυτού του κόμβου ώστε ο κόσμος να συμμετάσχει σε αυτό.';
$string['audience'] = 'Ακροατήριο';
$string['audienceadmins'] = 'Διαχειριστές Moodle';
$string['audienceeducators'] = 'Εκπαιδευτικοί';
$string['audience_help'] = 'Επιλέξτε το ακροατήριο για το οποίο προορίζεται αυτό το μάθημα.';
$string['badgesnumber'] = 'Αριθμός σημάτων ({$a})';
$string['badurlformat'] = 'Λάθος μορφή URL';
$string['cannotsearchcommunity'] = 'Λυπούμαστε, αλλά δεν έχετε τα κατάλληλα δικαιώματα να δείτε αυτή τη σελίδα';
$string['community'] = 'Κοινότητα';
$string['communityremoved'] = 'Αυτός ο σύνδεσμος μαθήματος έχει αφαιρεθεί από τη λίστα σας';
$string['confirmregistration'] = 'Επιβεβαίωση εγγραφής';
$string['contactable'] = 'Επικοινωνία από το κοινό';
$string['contactable_help'] = 'Εάν οριστεί σε ναι, ο κόμβος (hub) να εμφανίζει τη διεύθυνση ηλεκτρονικού ταχυδρομείου σας.';
$string['contactemail'] = 'Διεύθυνση επικοινωνίας ηλεκτρονικού ταχυδρομείου';
$string['contactname'] = 'Όνομα επικοινωνίας';
$string['contactphone'] = 'Τηλέφωνο';
$string['contactphone_help'] = 'Τα τηλέφωνα εμφανίζονται μόνο στην διαχειριστή του κόμβου και δεν εμφανίζονται δημόσια.';
$string['continue'] = 'Συνέχεια';
$string['contributornames'] = 'Άλλοι συνεισφέροντες';
$string['contributornames_help'] = 'Μπορείτε να χρησιμοποιήσετε αυτό το πεδίο για να σημειώσετε όποιους άλλους έχουν συνεισφέρει σε αυτό το μάθημα.';
$string['coursemap'] = 'Χάρτης μαθήματος';
$string['courseprivate'] = 'Προσωπικός';
$string['coursepublic'] = 'Δημόσιος';
$string['coursepublished'] = 'Αυτό το μάθημα έχει δημοσιευτεί επιτυχώς στο \'{$a}\'.';
$string['courseshortname'] = 'Σύντομο Όνομα';
$string['courseshortname_help'] = 'Δώστε ένα σύντομο όνομα για το μάθημα. Δεν χρειάζεται να είναι μοναδικό.';
$string['coursesnumber'] = 'Αριθμός μαθημάτων ({$a})';
$string['courseunpublished'] = 'Το μάθημα  {$a->courseshortname} δεν είναι πλέον δημοσιευμένο στο {$a->hubname}.';
$string['courseurl'] = 'URL μαθήματος';
$string['courseurl_help'] = 'Είναι το URL του μαθήματος. Αυτό το URL εμφανίζεται σαν  σύνδεσμος σε ένα αποτέλεσμα αναζήτησης.';
$string['creatorname'] = 'Δημιουργός';
$string['creatorname_help'] = 'Ο δημιουργός, είναι ο δημιουργός του μαθήματος.';
$string['creatornotes'] = 'Σημειώσεις Δημιουργού';
$string['creatornotes_help'] = 'Οι σημειώσεις του δημιουργού είναι ένας οδηγός για τους δασκάλους για το πως να χρησιμοποιήσουν το μάθημα.';
$string['deletescreenshots'] = 'Διαγραφή αυτών των στιγμιότυπων οθόνης.';
$string['deletescreenshots_help'] = 'Διαγραφή των στιγμιότυπων οθόνης που έχετε ανεβάσει.';
$string['demourl'] = 'Δοκιμαστικό URL';
$string['demourl_help'] = 'Δώστε το δοκιμαστικό URL του μαθήματός σας. Εξ\' ορισμού είναι το URL του μαθήματός σας. Το δοκιμαστικό URL εμφανίζεται σαν σύνδεσμος σε ένα αποτέλεσμα αναζήτησης.';
$string['description_help'] = 'Αυτή η περιγραφή θα εμφανίζεται στη λίστα μαθημάτων στον κόμβο (hub).';
$string['detectednotexistingpublication'] = 'To {$a->hubname} εμφανίζει ένα μάθημα το οποίο δεν υπάρχει πια. Ενημερώστε τον διαχειριστή του κόμβου (hub) ότι η δημοσίευση με αριθμό  {$a->id} πρέπει να αφαιρεθεί.';
$string['downloadable'] = 'Διαθέσιμο για λήψη';
$string['educationallevel'] = 'Μορφωτικό επίπεδο';
$string['educationallevel_help'] = 'Επιλέξτε το πιο ταιριαστό μορφωτικό επίπεδο στο οποίο εντάσσεται αυτό το μάθημα.';
$string['edulevelassociation'] = 'Συνεταιρισμός';
$string['edulevelcorporate'] = 'Εταιρικός';
$string['edulevelgovernment'] = 'Κυβερνητικός';
$string['edulevelprimary'] = 'Αρχική';
$string['edulevelsecondary'] = 'Δευτερεύουσα';
$string['eduleveltertiary'] = 'Τριτοβάθμια';
$string['emailalert'] = 'Ενημερώσεις ηλεκτρονικού ταχυδρομείου';
$string['emailalert_help'] = 'Εάν αυτό είναι ενεργό, ο διαχειριστής του κόμβου (hub) θα σας στέλνει ενημερώσεις για θέματα ασφαλείας και άλλα σημαντικά νέα.';
$string['enrollable'] = 'Εγγράψιμο';
$string['errorbadimageheightwidth'] = 'Η εικόνα πρέπει να έχει μέγιστες διαστάσεις {$a->width} X {$a->height}';
$string['errorcourseinfo'] = 'Παρουσιάστηκε σφάλμα κατά την ανάκτηση των δεδομένων μαθήματος από τον κόμβο (hub) ({$a}). Παρακαλώ προσπαθήστε ξανά να ανακτήσετε τα δεδομένα ανανεώνοντας τη σελίδα. Διαφορετικά, μπορείτε να συνεχίσετε τη διαδικασία εγγραφής με τα παρακάτω προκαθορισμένα δεδομένα.';
$string['errorcoursepublish'] = 'Παρουσιάστηκε σφάλμα κατά την δημοσίευση του μαθήματος ({$a}). Παρακαλώ δοκιμάστε ξανά αργότερα.';
$string['errorcoursewronglypublished'] = 'Επιστράφηκε σφάλμα κατά την δημοσίευση στον κόμβο (hub). Παρακαλώ δοκιμάστε ξανά αργότερα.';
$string['errorcron'] = 'Παρουσιάστηκε σφάλμα κατά την ενημέρωση της εγγραφής στο "{$a->hubname}" ({$a->errormessage})';
$string['errorcronnoxmlrpc'] = 'Το XML-RPC πρέπει να είναι ενεργό για να ενημερωθεί η εγγραφή.';
$string['errorhublisting'] = 'Παρουσιάστηκε σφάλμα κατά την ανάκτηση της λίστας των κόμβων από το Moodle.org, παρακαλώ δοκιμάστε ξανά αργότερα. ({$a})';
$string['errorlangnotrecognized'] = 'Ο παρεχόμενος κωδικός γλώσσας είναι άγνωστος για το Moodle. Παρακαλώ επικοινωνήστε με τον  {$a}';
$string['errorregistration'] = 'Παρουσιάστηκε σφάλμα κατά την εγγραφή, παρακαλώ δοκιμάστε ξανά αργότερα. ({$a})';
$string['errorunpublishcourses'] = 'Λόγω μη αναμενόμενου σφάλματος, τα μαθήματα δεν μπόρεσαν να διαγραφούν από τον κόμβο (hub). Προσπαθήστε ξανά αργότερα (συνιστάται) ή επικοινωνήστε με το διαχειριστή του κόμβου.';
$string['existingscreenshotnumber'] = 'Υπάρχουν {$a} στιγμιότυπα οθόνης. Μπορείτε να δείτε αυτά τα στιγμιότυπα σε αυτή τη σελίδα, μόνο όταν ο διαχειριστής ενεργοποιήσει το μάθημά σας.';
$string['existingscreenshots'] = 'Υπάρχοντα στιγμιότυπα σελίδας';
$string['forceunregister'] = 'Ναι, καθάρισε τα δεδομένα εγγραφής';
$string['forceunregisterconfirmation'] = 'Ο ιστότοπός σας δεν μπορεί να επικοινωνήσει με το {$a}. Αυτός ο κόμβος (hub) μπορεί να είναι προσωρινά μη διαθέσιμος. Σε περίπτωση που δεν επιθυμείτε να συνεχίσετε και να διαγράψετε τοπικά την εγγραφή, πατήστε ακύρωση και δοκιμάστε αργότερα.';
$string['geolocation'] = 'Γεωγραφική θέση';
$string['geolocation_help'] = 'Στο μέλλον, μπορεί να παρέχουμε αναζήτηση με βάση την γεωγραφική θέση. Εάν θέλετε να ορίσετε μια γεωγραφική θέση για το μάθημά σας χρησιμοποιήστε εδώ μια τιμή για μήκος και πλάτος (πχ : -31.947884,115.871285). Ένας τρόπος να το βρείτε αυτό είναι από τα Google Maps.';
$string['hub'] = 'Κόμβος';
$string['imageurl'] = 'URL εικόνας';
$string['imageurl_help'] = 'Αυτή η εικόνα θα εμφανίζεται στον κόμβο. Αυτή η εικόνα πρέπει να είναι διαθέσιμη από τον κόμβο ανά πάσα στιγμή. Η εικόνα θα πρέπει να έχει μέγιστες διαστάσεις {$a->width} X {$a->height}';
$string['information'] = 'Πληροφορίες';
$string['issuedbadgesnumber'] = 'Αριθμός των εκδοθέντων σημάτων ({$a})';
$string['language'] = 'Γλώσσα';
$string['language_help'] = 'Η κύρια γλώσσα του μαθήματος';
$string['lasttimechecked'] = 'Τελευταία φορά που ελέγχθηκαν';
$string['licence'] = 'Άδεια';
$string['licence_help'] = 'Επιλέξτε την άδεια που θέλετε να χρησιμοποιήσετε κατά την διανομή του μαθήματός σας.';
$string['logourl'] = 'URL λογότυπου';
$string['modulenumberaverage'] = 'Μέσος αριθμός των ενοτήτων των μαθημάτων ({$a})';
$string['moodleorg'] = 'Moodle.org';
$string['mustselectsubject'] = 'Πρέπει να επιλέξετε ένα θέμα';
$string['name_help'] = 'Αυτό το όνομα θα εμφανίζεται στη λίστα των μαθημάτων.';
$string['neverchecked'] = 'Δεν έχει ελεγχθεί ποτέ';
$string['no'] = 'Όχι';
$string['nocheckstatusfromunreghub'] = 'Ο ιστότοπος δεν είναι εγγεγραμμένος στον κόμβο οπότε δεν μπορεί να ελεγχθεί η κατάστασή του.';
$string['nohubselected'] = 'Δεν έχει επιλεγεί κόμβος';
$string['none'] = 'Κανένα';
$string['nosearch'] = 'Μην δημοσιεύσεις τον κόμβο ή τα μαθήματα';
$string['notregisteredonhub'] = 'Ο διαχειριστής σας πρέπει να γράψει αυτόν τον ιστότοπο σε έναν τουλάχιστον κόμβο πριν μπορέσετε να δημοσιεύσετε ένα μάθημα. Επικοινωνήστε με τον διαχειριστή του ιστοτόπου σας.';
$string['notregisteredonmoodleorg'] = 'Ο διαχειριστής σας πρέπει να γράψει αυτόν τον ιστότοπο στο moodle.org.';
$string['operation'] = 'Ενέργειες';
$string['orenterprivatehub'] = 'Εναλλακτικά, δώστε ένα ιδιωτικό URL κόμβου:';
$string['participantnumberaverage'] = 'Μέσος αριθμός συμμετεχόντων ({$a})';
$string['postaladdress'] = 'Ταχυδρομική διεύθυνση';
$string['postaladdress_help'] = 'Ταχυδρομική διεύθυνση αυτού του ιστοτόπου, ή της ενότητας την οποία αντιπροσωπεύει αυτός ο ιστότοπος.';
$string['postsnumber'] = 'Αριθμός μηνυμάτων ({$a})';
$string['previousregistrationdeleted'] = 'Η προηγούμενη εγγραφή έχει διαγραφεί από τον  {$a}. Μπορείτε να ξεκινήσετε πάλι την διαδικασία εγγραφής. Ευχαριστώ.';
$string['prioritise'] = 'Προτεραιότητα';
$string['privacy'] = 'Προστασία Προσωπικών Δεδομένων';
$string['privacy_help'] = 'Ο κόμβος μπορεί να χρειάζεται να δείξει μια λίστα με τους εγγεγραμμένους ιστοτόπους. Εάν γίνει αυτό, μπορείτε να επιλέξετε εάν θέλετε να εμφανίζεστε στη λίστα.';
$string['private'] = 'Προσωπικό';
$string['privatehuburl'] = 'Προσωπικό URL κόμβου';
$string['publicationinfo'] = 'Πληροφορίες δημοσίευσης μαθήματος';
$string['publichub'] = 'Δημόσιος κόμβος';
$string['publishcourseon'] = 'Δημοσίευση στο {$a}';
$string['publishedon'] = 'Δημοσιεύτηκε στις';
$string['publisheremail'] = 'Διεύθυνση ηλεκτρονικού ταχυδρομείου εκδότη';
$string['publisheremail_help'] = 'Η διεύθυνση ηλεκτρονικού ταχυδρομείου εκδότη επιτρέπει στον διαχειριστή του κόμβου να ενημερώνει τον εκδότη για όποια αλλαγή γίνεται στην κατάσταση του εκδοθέντος μαθήματος,';
$string['publishername'] = 'Εκδότης';
$string['publishername_help'] = 'Ο εκδότης είναι ο άνθρωπος ή ο οργανισμός οποίος είναι ο επίσημος εκδότης του μαθήματος. Εκτός κι αν κάνετε τη δημοσίευση εκ μέρους κάποιου άλλου, συνήθως θα είστε εσείς.';
$string['publishon'] = 'Δημοσίευση σε';
$string['publishonspecifichub'] = 'Δημοσίευση σε άλλο Κόμβο';
$string['questionsnumber'] = 'Αριθμός ερωτήσεων ({$a})';
$string['readvertiseon'] = 'Ενημέρωση πληροφοριών διαφήμισης στο {$a}';
$string['registeredcourses'] = 'Εγγεγραμμένα μαθήματα';
$string['registeredmoodleorg'] = 'Moodle.org ({$a})';
$string['registeredon'] = 'Εκεί όπου η ιστοσελίδας σας είναι γραμμένη';
$string['registeredsites'] = 'Εγγεγραμμένες ιστοσελίδες';
$string['registermoochtips'] = 'Για να γραφτείτε στο Moodle.net, η ιστοσελίδα σας πρέπει να είναι εγγεγραμμένη στο Moodle.org.';
$string['registersite'] = 'Εγγραφή με {$a}';
$string['registerwith'] = 'Εγγραφή με ένα κόμβο';
$string['registrationconfirmed'] = 'Επιβεβαίωση εγγραφής ιστοσελίδας';
$string['registrationconfirmedon'] = 'Ευχαριστούμε για την εγγραφή της ιστοσελίδας σας. Οι πληροφορίες εγγραφής θα παραμείνουν ενημερωμένες από την αυτόματη εργασία \'Εγγραφή ιστοσελίδας\'';
$string['registrationinfo'] = 'Πληροφορίες εγγραφής';
$string['registrationupdated'] = 'Η εγγραφή έχει ενημερωθεί.';
$string['registrationupdatedfailed'] = 'Απέτυχε η ενημέρωση της εγγραφής.';
$string['removefromhub'] = 'Αφαίρεση από τον κόμβο';
$string['renewregistration'] = 'Ανανέωση εγγραφής';
$string['resourcesnumber'] = 'Αριθμός πόρων ({$a})';
$string['restartregistration'] = 'Επανεκκίνηση εγγραφής';
$string['roleassignmentsnumber'] = 'Αριθμός αναθέσεων ρόλων ({$a})';
$string['screenshots'] = 'Στιγμιότυπα οθόνης';
$string['screenshots_help'] = 'Όλα τα στιγμιότυπα οθόνης του μαθήματος θα εμφανίζονται στα αποτελέσματα αναζήτησης.';
$string['search'] = 'Αναζήτηση';
$string['selecthub'] = 'Επιλογή κόμβου';
$string['selecthubforadvertise'] = 'Επιλέξτε κόμβο για διαφήμιση';
$string['selecthubforsharing'] = 'Επιλέξτε κόμβο για ανέβασμα';
$string['selecthubinfo'] = 'Ένας κοινοτικός κόμβος είναι ένας διακομιστής ο οποίος εμφανίζει τις λίστες των μαθημάτων. Μπορείτε να δημοσιεύσετε τα μαθήματά σας μόνο σε κόμβους στους οποίους αυτή η moodle ιστοσελίδα έχει εγγραφεί. Εάν ο κόμβος που θέλετε, δεν εμφανίζεται παρακάτω, παρακαλώ επικοινωνήστε με τον διαχειριστή της ιστοσελίδας σας.';
$string['sendfollowinginfo'] = 'Επιπλέον πληροφορίες';
$string['sendfollowinginfo_help'] = 'Οι παρακάτω πληροφορίες θα αποσταλούν για να συνεισφέρουν μόνο στα γενικά στατιστικά. Δεν θα δημοσιευτούν σε κάποια λίστα της ιστοσελίδας.';
$string['sendingcourse'] = 'Αποστολή μαθήματος';
$string['sendingsize'] = 'Παρακαλώ περιμένετε, το αρχείο του μαθήματος μεταφορτώνεται ({$a->total}Mb)...';
$string['sent'] = '...ολοκληρώθηκε';
$string['settingsupdated'] = 'Οι ρυθμίσεις έχουν ενημερωθεί.';
$string['share'] = 'Μοιραστείτε αυτό το μάθημα ώστε να το κατεβάσουν κι άλλοι άνθρωποι';
$string['shared'] = 'Κοινό';
$string['shareon'] = 'Μεταφορτώστε αυτό το μάθημα στο {$a}';
$string['shareonhub'] = 'Μεταφορτώστε αυτό το μάθημα σε έναν κόμβο';
$string['sharepublication_help'] = 'Η μεταφόρτωση του μαθήματος σε έναν κοινοτικό κόμβο διακομιστή, θα δώσει τη δυνατότητα στους ανθρώπους να το κατεβάσουν και να το εγκαταστήσουν στις δικές τους ιστοσελίδες moodle.';
$string['siteadmin'] = 'Διαχειριστής';
$string['siteadmin_help'] = 'Το πλήρες όνομα του διαχειριστή της ιστοσελίδας.';
$string['sitecountry'] = 'Χώρα';
$string['sitecountry_help'] = 'Η χώρα στην οποία βρίσκεται ο οργανισμός σας.';
$string['sitecreated'] = 'Δημιουργήθηκε η ιστοσελίδα.';
$string['sitedesc_help'] = 'Αυτή η περιγραφή της ιστοσελίδας μπορεί να εμφανίζεται στη λίστα των ιστοσελίδων. Παρακαλώ να χρησιμοποιήσετε μόνο απλό κείμενο.';
$string['siteemail'] = 'Διεύθυνση ηλεκτρονικού ταχυδρομείου';
$string['siteemail_help'] = 'Πρέπει να δώσετε μια διεύθυνση ηλεκτρονικού ταχυδρομείου ώστε ο διαχειριστής του κόμβου να μπορέσει να επικοινωνήσει μαζί σας, εάν χρειαστεί. 
Συνιστάται να εισάγετε μια διεύθυνση email που σχετίζεται με μια θέση (παράδειγμα: sitemanager@example.com) και όχι απευθείας με ένα πρόσωπο.';
$string['sitegeolocation'] = 'Γεωγραφική θέση';
$string['sitegeolocation_help'] = 'Στο μέλλον μπορεί να παρέχουμε αναζήτηση κόμβων με γεωγραφική θέση. Εάν θέλετε να ορίσετε την θέση της ιστοσελίδας σας χρησιμοποιήστε εδώ τιμές μήκους και πλάτους  (πχ: -31.947884,115.871285). Ένας τρόπος να τα βρείτε αυτά είναι μέσω Google Maps.';
$string['sitelang'] = 'Γλώσσα';
$string['sitelang_help'] = 'Η γλώσσα της ιστοσελίδας σας θα φαίνεται στη λίστα με τις ιστοσελίδες.';
$string['sitename_help'] = 'Το όνομα της ιστοσελίδας θα φαίνεται στη λίστα με τις ιστοσελίδες, εάν το επιτρέπει ο κόμβος.';
$string['sitephone'] = 'Τηλέφωνο';
$string['sitephone_help'] = 'Το τηλέφωνο θα είναι ορατό μόνο από τον διαχειριστή του κόμβου.';
$string['siteprivacy'] = 'Προστασία Προσωπικών Δεδομένων';
$string['siteprivacylinked'] = 'Δημοσιεύστε το όνομα της ιστοσελίδας με ένα σύνδεσμο';
$string['siteprivacynotpublished'] = 'Σας παρακαλούμε να μην δημοσιεύσετε αυτή την ιστοσελίδα';
$string['siteprivacypublished'] = 'Δημοσιεύστε μόνο το όνομα του δικτυακού τόπου';
$string['siteregconfcomment'] = 'Η ιστοσελίδα σας χρειάζεται μια τελική επιβεβαίωση στο {$a} (προκειμένου να αποφευχθεί το spam στο on {$a})';
$string['siteregistrationcontact'] = 'Φόρμα επικοινωνίας';
$string['siteregistrationcontact_help'] = 'Εάν το επιτρέψετε, άλλοι άνθρωποι θα είναι σε θέση να επικοινωνήσουν μαζί σας μέσω της φόρμας επικοινωνίας στον κόμβο. Ποτέ δεν θα είναι σε θέση να δουν τη διεύθυνση του ηλεκτρονικού ταχυδρομείου σας.';
$string['siteregistrationemail'] = 'Ειδοποιήσεις μέσω ηλεκτρονικού ταχυδρομείου';
$string['siteregistrationemail_help'] = 'Αν ενεργοποιήσετε αυτή τη ρύθμιση, ο διαχειριστής του κόμβου θα μπορεί να σας στείλει e-mail σας για να σας ενημερώσει για σημαντικά νέα, όπως τα θέματα ασφάλειας.';
$string['siteregistrationupdated'] = 'Ενημερώθηκε η εγγραφή της ιστοσελίδας';
$string['siterelease'] = 'Έκδοση Moodle';
$string['siterelease_help'] = 'Ο αριθμός έκδοσης του Moodle σε αυτή την ιστοσελίδα.';
$string['siteupdatedcron'] = 'Ενημέρωση της εγγραφή της ιστοσελίδας στο "{$a}"';
$string['siteupdatesend'] = 'Ολοκληρώθηκαν οι ενημερώσεις της εγγραφής στους κόμβους.';
$string['siteupdatesstart'] = 'Ξεκινάει η ενημέρωση της εγγραφή στους κόμβους ...';
$string['siteurl'] = 'URL ιστοσελίδας';
$string['siteurl_help'] = 'Η διεύθυνση URL, είναι η διεύθυνση αυτής της ιστοσελίδας. Εάν οι ρυθμίσεις απορρήτου επιτρέπουν στους ανθρώπους να δουν τις διευθύνσεις της ιστοσελίδα, τότε αυτή είναι η διεύθυνση URL που θα χρησιμοποιηθεί.';
$string['siteversion'] = 'Έκδοση Moodle';
$string['siteversion_help'] = 'Η έκδοση Moodle για αυτή την ιστοσελίδα.';
$string['statistics'] = 'Στατιστικά προστασία της ιδιωτικής ζωής';
$string['status'] = 'Κατάλογος κόμβου';
$string['statuspublished'] = 'Εμφανίζεται';
$string['statusunpublished'] = 'Δεν Εμφανίζεται';
$string['subject'] = 'Θέμα';
$string['subject_help'] = 'Επιλέξτε την κύρια θεματική περιοχή που καλύπτει το μάθημα.';
$string['tags'] = 'Ετικέτες';
$string['tags_help'] = 'Οι Ετικέτες βοηθούν στην περαιτέρω κατηγοριοποίηση του μαθήματός σας και το βοηθούν να βρεθεί πιο εύκολα. Παρακαλούμε χρησιμοποιήστε απλές, κατανοητές λέξεις και διαχωρίστε τες με ένα κόμμα. Παράδειγμα: μαθηματικά, άλγεβρα, γεωμετρία';
$string['trustme'] = 'Εμπιστοσύνη';
$string['type'] = 'Διαφημιζόμενο / Διαμοιραζόμενο';
$string['unknownstatus'] = 'Άγνωστο';
$string['unlistedurl'] = 'URL κόμβου εκτός λίστας';
$string['unprioritise'] = 'Κατάργηση προτεραιοποίησης';
$string['unpublish'] = 'Κατάργηση δημοσίευσης';
$string['unpublishalladvertisedcourses'] = 'Αφαιρέστε όλα τα μαθήματα που αυτή τη στιγμή διαφημίζονται στον κόμβο';
$string['unpublishalluploadedcourses'] = 'Αφαιρέθηκαν όλα τα μαθήματα που είχαν φορτωθεί σε ένα κόμβο';
$string['unpublishconfirmation'] = 'Θέλετε πραγματικά να αφαιρέσετε το μάθημα "{$a->courseshortname}" από τον κόμβο "{$a->hubname}"';
$string['unpublishcourse'] = 'Κατάργηση δημοσίευσης {$a}';
$string['unregister'] = 'Κατάργηση εγγραφής';
$string['unregisterconfirmation'] = 'Πρόκειται να καταργήσετε την εγγραφή αυτής της ιστοσελίδας από τον κόμβο {$a}. Μόλις αποσυνδεθείτε από αυτή, δεν θα μπορείτε να διαχειρίζεστε πλέον τα μαθήματα που θα μπορεί να έχετε αφήσει εκεί. Είστε σίγουροι ότι θέλετε να καταργήσετε την εγγραφή;';
$string['unregisterfrom'] = 'Κατάργηση εγγραφής από {$a}';
$string['unregistrationerror'] = 'Παρουσιάστηκε σφάλμα ενώ η σελίδα προσπαθούσε να διαγραφεί από τον κόμβο: {$a}';
$string['untrustme'] = 'Μη έμπιστο';
$string['update'] = 'Ενημέρωση';
$string['updatesite'] = 'Ενημέρωση εγγραφής στο {$a}';
$string['updatestatus'] = 'Έλεγχος τώρα.';
$string['uploaded'] = 'Μεταφορτωμένο';
$string['url'] = 'URL κόμβου';
$string['urlalreadyregistered'] = 'Η ιστοσελίδα σας φαίνεται να είναι ήδη εγγεγραμμένη σε αυτόν τον κόμβο, το οποίο σημαίνει ότι κάτι έχει πάει στραβά. Παρακαλούμε επικοινωνήστε με το διαχειριστή του κόμβου για να επαναφέρετε την εγγραφή σας, ώστε να δοκιμάσετε ξανά.';
$string['usersnumber'] = 'Αριθμός χρηστών ({$a})';
$string['warning'] = 'ΠΡΟΕΙΔΟΠΟΙΗΣΗ';
$string['wrongtoken'] = 'Η εγγραφή απέτυχε για κάποιον άγνωστο λόγο (δίκτυο;). Παρακαλώ δοκιμάστε ξανά.';
$string['wrongurlformat'] = 'Κακή μορφή διεύθυνσης URL';
$string['xmlrpcdisabledcommunity'] = 'Η επέκταση XML-RPC δεν είναι ενεργή στον διακομιστή. Δεν μπορείτε να αναζητήσετε και να κατεβάσετε μαθήματα.';
$string['xmlrpcdisabledpublish'] = 'Η επέκταση XML-RPC δεν είναι ενεργή στον διακομιστή. Δεν μπορείτε να δημοσιεύσετε ή να διαχειριστείτε δημοσιευμένα μαθήματα.';
$string['xmlrpcdisabledregistration'] = 'Η επέκταση XML-RPC δεν είναι ενεργή στον διακομιστή. Δεν θα είστε σε θέση να ακυρώσετε ή να ενημερώσετε την εγγραφή σας, ωσότου το ενεργοποιήσετε.';
