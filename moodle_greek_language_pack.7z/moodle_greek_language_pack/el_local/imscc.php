<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage imscc
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cc2moodle_checking_schema'] = 'Μορφοποίηση CC! Έλεγχος σχήματος ...';
$string['cc2moodle_invalid_schema'] = 'Το σχήμα δεν είναι έγκυρο.';
$string['cc2moodle_manifest_dont_load'] = 'Δεν μπορεί να φορτωθεί το XML manifest.';
$string['cc2moodle_req_auth'] = 'ΣΦΑΛΜΑ: Το πακέτο Common Cartridge απαιτεί άδεια.';
$string['cc2moodle_valid_schema'] = 'Έγκυρο σχήμα.';
$string['cc_import_req_dom'] = 'ΣΦΑΛΜΑ: Η εισαγωγή του Common Cartridge απαιτεί την προέκταση DOM.';
$string['cc_import_req_libxml'] = 'ΣΦΑΛΜΑ: Η εισαγωγή του Common Cartridge απαιτεί την προέκταση LIBXML.';
$string['cc_import_req_libxmlminversion'] = 'ΣΦΑΛΜΑ: Η εισαγωγή του Common Cartridge απαιτεί την προέκταση LIBXML έκδοση 2.6.30 ή νεότερη.';
$string['cc_import_req_php5'] = 'ΣΦΑΛΜΑ: Η εισαγωγή του Common Cartridge απαιτεί PHP 5 ή μεγαλύτερη.';
$string['cc_import_req_xsl'] = 'ΣΦΑΛΜΑ: Η εισαγωγή του Common Cartridge απαιτεί XSL.';
$string['checkingforimscc'] = 'Έλεγχος για IMS-CC...';
$string['enable_cc_import'] = 'Ενεργοποίηση εισαγωγής CC';
$string['enable_cc_import_description'] = 'Αυτή η ρύθμιση επιτρέπει την εισαγωγή των Common Cartridge (IMS-CC) πακέτων χρησιμοποιώντας την τυπική επαναφορά της λειτουργικότητας. Σημείωση: απαιτεί PHP5, DOM, XSL και LibXML (2.6.30 ή νεότερη έκδοση) τα οποία θα πρέπει να εγκατασταθούν στο διακομιστή.';
