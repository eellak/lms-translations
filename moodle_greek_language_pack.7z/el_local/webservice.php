<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage webservice
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accessexception'] = 'Εξαίρεση ελέγχου πρόσβασης';
$string['addaservice'] = 'Προσθήκη υπηρεσίας';
$string['addcapabilitytousers'] = 'Ελέγξτε τις δυνατότητες των χρηστών';
$string['addcapabilitytousersdescription'] = 'Οι χρήστες θα πρέπει να έχουν δύο δυνατότητες - webservice: createtoken και μια δυνατότητα που θα ταιριάζει με τα πρωτόκολλα που χρησιμοποιούνται, για παράδειγμα webservice/rest:use, webservice/soap:use. Για να επιτευχθεί αυτό, δημιουργήστε έναν ρόλο για web services, με τις κατάλληλες ικανότητες και εκχωρήσετε τον στο χρήστη των web services, σαν ρόλο του συστήματος.';
$string['addfunction'] = 'Προσθήκη συνάρτησης';
$string['addfunctionhelp'] = 'Επιλέξτε τη συνάρτηση που θα προσθέσετε στο service.';
$string['addfunctions'] = 'Προσθήκη συναρτήσεων';
$string['addfunctionsdescription'] = 'Επιλέξτε τις απαραίτητες συναρτήσεις για το νέο service.';
$string['addrequiredcapability'] = 'Αναθέστε/αφαιρέστε την απαραίτητη δυνατότητα';
$string['addservice'] = 'Προσθήκη νέου service: {$a->name} (id: {$a->id})';
$string['addservicefunction'] = 'Προσθήκη συναρτήσεων στο service "{$a}"';
$string['amftestclient'] = 'AMF test client';
$string['apiexplorer'] = 'API explorer';
$string['apiexplorernotavalaible'] = 'Ο API explorer δεν είναι διαθέσιμος';
$string['arguments'] = 'Ορίσματα';
$string['authmethod'] = 'Μέθοδος ταυτοποίησης';
$string['callablefromajax'] = 'Καλούμενο από AJAX';
$string['cannotcreatetoken'] = 'Δεν έχετε άδεια να δημιουργήσετε το κλειδί (token) για το web service {$a}.';
$string['cannotgetcoursecontents'] = 'Τα περιεχόμενα των μαθημάτων δεν μπορούν να ανακτηθούν';
$string['checkusercapability'] = 'Έλεγχος δυνατοτήτων χρήστη';
$string['checkusercapabilitydescription'] = 'Ο χρήστης θα πρέπει να έχει τις κατάλληλες δυνατότητες σύμφωνα με τα πρωτόκολλα που χρησιμοποιούνται, για παράδειγμα webservice/rest:use, webservice/soap:use. Για να επιτευχθεί αυτό, δημιουργήστε έναν web services ρόλο με τις δυνατότητες που επιτρέπονται για το  πρωτοκόλλο και εκχωρήσετε τον στο χρήστη των web services σαν ρόλο του συστήματος.';
$string['context'] = 'Πλαίσιο';
$string['createservicedescription'] = 'Ένα web service είναι σύνολο από συναρτήσεις. Θα επιτρέψετε στον χρήστη να έχει πρόσβαση σε ένα νέο service. Από την σελίδα <strong> Προσθήκη υπηρεσίας</ strong> επιλέξετε τα "Ενεργοποίηση" και επιλογές "Εξουσιοδοτημένων χρηστών». Στη συνέχεια επιλέξτε «Δεν απαιτείται κάποια δυνατότητα».';
$string['createserviceforusersdescription'] = 'Ένα web service είναι σύνολο από συναρτήσεις. Θα επιτρέψετε στους χρήστες να έχουν πρόσβαση σε  σε ένα νέο service. Από την σελίδα <strong> Προσθήκη υπηρεσίας</ strong> επιλέξετε τα "Ενεργοποίηση" και επιλογές "Εξουσιοδοτημένων χρηστών». Στη συνέχεια επιλέξτε «Δεν απαιτείται κάποια δυνατότητα».';
$string['createtokenforuser'] = 'Δημιουργία κλειδιού (token) για έναν χρήστη';
$string['createtokenforuserdescription'] = 'Δημιουργία κλειδιού (token) για έναν χρήστη web services.';
$string['createuser'] = 'Δημιουργήστε ένα συγκεκριμένο χρήστη';
$string['createuserdescription'] = 'Απαιτείται ένας χρήστης web services, για να εκπροσωπήσει το σύστημα που ελέγχει το Moodle.';
$string['criteriaerror'] = 'Μη επαρκη δικαιώματα για να αναζητήσετε σε ένα κριτήριο.';
$string['default'] = 'Προεπιλογή σε  "{$a}"';
$string['deleteaservice'] = 'Διαγραφή service';
$string['deleteservice'] = 'Διαγραφή service: {$a->name} (id: {$a->id})';
$string['deleteserviceconfirm'] = 'Η διαγραφή ενός service θα διαγράψει και τα κλειδιά (tokens) που σχετίζονται με αυτή την υπηρεσία. Θέλετε σίγουρα να διαγράψετε το εξωτερικό service "{$a}";';
$string['deletetokenconfirm'] = 'Θέλετε πραγματικά να διαγράψετε το κλειδί (token) του  web service για τον χρήστη <strong>{$a->user}</strong> στο service <strong>{$a->service}</strong>?';
$string['disabledwarning'] = 'Όλα τα πρωτόκολλα web service είναι απενεργοποιημένα. Η ρύθμιση "Ενεργοποιήση web services" βρίσκεται στις Προηγμένες επιλογές.';
$string['doc'] = 'Τεκμηρίωση';
$string['docaccessrefused'] = 'Δεν έχετε δικαίωματα να δείτε την τεκμηρίωση για αυτό το κλειδί (token)';
$string['documentation'] = 'Τεκμηρίωση web service';
$string['downloadfiles'] = 'Μπορείτε να κατεβάσετε αρχεία';
$string['downloadfiles_help'] = 'Αν ενεργοποιηθεί, κάθε χρήστης μπορεί να κατεβάσει τα αρχεία με τα κλειδιά ασφαλείας του. Φυσικά περιορίζεται στα αρχεία τα οποία μπορεί να κατεβάσει από το site.';
$string['editservice'] = 'Επεξεργασια υπηρεσίας: {$a->name} (id: {$a->id})';
$string['enabledocumentation'] = 'Ενεργοποίηση τεκμηρίωσης για προγραμματιστές';
$string['enabledocumentationdescription'] = 'Λεπτομερής τεκμηρίωση είναι διαθέσιμα για τα ενεργά web services πρωτόκολλα';
$string['enablemobilewsoverview'] = 'Πηγαίνετε στη {$a->manageservicelink} σελίδα διαχείρισης, επιλέξτε τη ρύθμιση  "{$a->enablemobileservice}" και σώστε το. Τα πάντα θα στηθούν για εσάς και όλοι οι χρήστες του site θα είναι σε θέση να χρησιμοποιήσουν το επίσημο Moodle app. Τρέχουσα κατάσταση: {$a->wsmobilestatus}';
$string['enableprotocols'] = 'Ενεργοποίηση πρωτοκόλλων';
$string['enableprotocolsdescription'] = 'Τουλάχιστον ένα πρωτόκολλο πρέπει να είναι ενεργό. Για λόγους ασφαλείας, πρέπει να είναι ενεργά, μόνο πρωτόκολλα που χρησιμοποιούνται.';
$string['enablews'] = 'Ενεργοποιήση web services';
$string['enablewsdescription'] = 'Τα web services πρέπει να είναι ενεργοποιημένα στις Προηγμένες επιλογές.';
$string['entertoken'] = 'Εισάγετε ένα κλειδί ασφαλείας/token:';
$string['error'] = 'Σφάλμα: {$a}';
$string['errorcatcontextnotvalid'] = 'Δεν μπορείτε να τρέξετε συναρτήσεις στα πλαίσια της κατηγορίας  (κωδικός κατηγορίας:{$a->catid}). Το μήνυμα λάθους ήταν: {$a->message}';
$string['errorcodes'] = 'Μήνυμα λάθους';
$string['errorcoursecontextnotvalid'] = 'Δεν μπορείτε να τρέξετε συναρτήσεις στα πλαίσια του μαθήματος (κωδικός μαθήματος:{$a->catid}). Το μήνυμα λάθους ήταν: {$a->message}';
$string['errorinvalidparam'] = 'Η παράμετρος "{$a}" δεν είναι έγκυρη.';
$string['errornotemptydefaultparamarray'] = 'Η παράμετρος περιγραφής του web service που ονομάζεται \'{$a}\' είναι μια απλή ή πολλαπλή δομή. Η προεπιλογή μπορεί να είναι μόνο άδειο array. Ελέγξτε την περιγραφή του web service.';
$string['erroroptionalparamarray'] = 'Η παράμετρος περιγραφής του web service που ονομάζεται \'{$a}\' είναι μια απλή ή πολλαπλή δομή. Δεν μπορίε να είναι ορισμένη σαν VALUE_OPTIONAL. Ελέγξτε την περιγραφή του web service.';
$string['eventwebservicefunctioncalled'] = 'Καλέστηκε η συνάρτηση του  	
Web service';
$string['eventwebserviceloginfailed'] = 'Απέτυχε η σύνδεση του  	
Web service';
$string['eventwebserviceservicecreated'] = 'Δημιουργήθηκε το Web service';
$string['eventwebserviceservicedeleted'] = 'Διαγράφηκε το Web service';
$string['eventwebserviceserviceupdated'] = 'Ενημερώθηκε το Web service';
$string['eventwebserviceserviceuseradded'] = 'Προστέθηκε ο χρήστης στο Web service';
$string['eventwebserviceserviceuserremoved'] = 'Αφαιρέθηκε ο χρήστης από το Web service';
$string['eventwebservicetokencreated'] = 'Δημιουργήθηκε το κλειδι (token) του Web service';
$string['eventwebservicetokensent'] = 'Στάλθηκε το κλειδι (token) του Web service';
$string['execute'] = 'Εκτέλεση';
$string['executewarnign'] = 'ΠΡΟΣΟΧΗ: Αν πατήσετε Εκτέλεση η βάση δεδομένων σας θα τροποποιηθεί και οι αλλαγές δεν μπορούν να ανακληθούν αυτόματα!';
$string['externalservicefunctions'] = 'Συναρτήσεις εξωτερικών services';
$string['externalserviceusers'] = 'Χρήστες εξωτερικών services';
$string['failedtolog'] = 'Αποτυχία καταγραφής';
$string['filenameexist'] = 'Το όνομα αρχείου υπάρχει ήδη: {$a}';
$string['forbiddenwsuser'] = 'Δεν μπορείτε να δημιουργήσετε κλειδί (token) για έναν ανεπιβεβαίωτο, διεγραμμένο, ανεσταλμένο ή επισκέπτη χρήστη.';
$string['function'] = 'Συνάρτηση';
$string['generalstructure'] = 'Γενική δομή';
$string['information'] = 'Πληροφορίες';
$string['installexistingserviceshortnameerror'] = 'Ένα web service με το σύντομο όνομα "{$a}" υπάρχει ήδη. Δεν μπορείτε να εγκαταστήσετε / ενημερώσετε ένα διαφορετικό web service με αυτό το σύντομο όνομα.';
$string['installserviceshortnameerror'] = 'Προγραμματιστικό σφάλμα: το σύντομο όνομα του service "{$ a}" θα πρέπει να περιέχει αριθμούς, γράμματα και _- .. μόνο.';
$string['invalidextparam'] = 'Άκυρη παράμετρος εξωτερικού api: {$a}';
$string['invalidextresponse'] = 'Άκυρη απάντηση εξωτερικού api: {$a}';
$string['invalidiptoken'] = 'Ακυρο κλειδί (token) - η ΙΡ σας δεν υποστηρίζεται';
$string['invalidtimedtoken'] = 'Ακυρο κλειδί (token) - το  κλειδί (token) έχει λήξει';
$string['invalidtoken'] = 'Ακυρο κλειδί (token) - το  κλειδί (token) δεν βρέθηκε';
$string['iprestriction_help'] = 'Ο χρήστης θα πρέπει να καλέσετε το web service από τις επιτρεπόμενες IPs (χωρισμένες με κόμμα).';
$string['keyshelp'] = 'Τα κλειδιά χρησιμοποιούνται για να έχετε πρόσβαση στον Moodle λογαριασμό σας από εξωτερικές εφαρμογές.';
$string['missingcaps'] = 'Απούσες δυνατότητες';
$string['missingcaps_help'] = 'Είναι μια λίστα με δυνατότητες για το service, τις οποίες ο επιλεγμένος χρήστης δεν έχει. Οι απούσες δυνατότητες πρέπει να προστεθούν στον ρόλο του χρήστη για να μπορέσει να χρησιμοποιήσει το service.';
$string['missingpassword'] = 'Λείπει ο κωδικός πρόσβασης';
$string['missingrequiredcapability'] = 'Απαιτείται η δυνατότηα {$a}.';
$string['missingusername'] = 'Λείπει το όνομα πρόσβασης';
$string['missingversionfile'] = 'Προγραμματιστικό λάθος: το αρχείο version.php λείπει από το {$a}';
$string['nameexists'] = 'Αυτό το όνομα χρησιμοποιείται ήδη από άλλο service';
$string['nocapabilitytouseparameter'] = 'Ο χρήστης δεν έχει τη δυνατότητα που χρειάζεται για να χρησιμοποιήσει την παράμετρο {$a}';
$string['nofunctions'] = 'Το service δεν έχει συναρτήσεις.';
$string['norequiredcapability'] = 'Δεν απαιτείται κάποια δυνατότητα';
$string['onesystemcontrolling'] = 'Επιτρέψτε σε ένα εξωτερικό σύστημα να ελέγχει το Moodle';
$string['onesystemcontrollingdescription'] = 'Τα επόμενα βήματα θα σας βοηθήσουν να στήσετε τα web services του Moodle ώστε να επιτρέψετε σε ένα εξωτερικό σύστημα να αλληλεπιδρά με το Moodle. Αυτό περιλαμβάνει το στήσιμο μεθόδου ταυτοποίησης με token (κλειδί ασφαλείας).';
$string['optional'] = 'Προεραιτικός';
$string['passwordisexpired'] = 'Ο κωδικός πρόσβασης είναι ληγμένος.';
$string['phpparam'] = 'XML-RPC (PHP structure)';
$string['phpresponse'] = 'XML-RPC (PHP structure)';
$string['postrestparam'] = 'PHP κώδικας για REST (POST request)';
$string['potusers'] = 'Μη ταυτοποιημένοι χρήστες';
$string['potusersmatching'] = 'Ταύτιση μη ταυτοποιημένων χρηστών';
$string['print'] = 'Εκτύπωση όλων';
$string['removefunction'] = 'Αφαίρεση';
$string['removefunctionconfirm'] = 'Θέλετε πραγματικά να αφαιρέσετε τη συνάρτηση  "{$a->function}" από το service "{$a->service}";';
$string['requireauthentication'] = 'Αυτή η μέθοδος απαιτεί ταυτοποίηση με xxx άδεια.';
$string['required'] = 'Υποχρεωτικό';
$string['requiredcapability'] = 'Απαιτούμενη δυνατότητα';
$string['requiredcapability_help'] = 'Εάν οριστεί, μόνο χρήστες με την απαιτούμενη δυνατότητα θα έχουν πρόσβαση στο service.';
$string['requiredcaps'] = 'Απαιτούμενες δυνατότητες';
$string['resettokenconfirm'] = 'Θέλετε πραγματικά να επαναφέρετε το κλειδί για το αυτό το web service και για τον χρήστη <strong>{$a->user}</strong> για το service <strong>{$a->service}</strong>;';
$string['resettokenconfirmsimple'] = 'Θέλετε πραγματικά να επαναφέρετε αυτό το κλειδί; Όλοι οι σωσμένοι σύνδεσμοι που περιέχουν το παλιό κλειδί δεν θα δουλεύουν πλέον.';
$string['response'] = 'Απάντηση';
$string['restcode'] = 'REST';
$string['restexception'] = 'REST';
$string['restoredaccountresetpassword'] = 'Ο αποκατεστημένος λογαριασμός χρειάζεται να επαναφέρει τον κωδικό πρόσβασης για να μπορέσει να πάρει κλειδί.';
$string['restparam'] = 'REST (POST parameters)';
$string['securitykey'] = 'Κλειδί ασφαλείας (token)';
$string['selectauthorisedusers'] = 'Επιλέξτε ταυτοποιημένους χρήστες';
$string['selectedcapability'] = 'Επιλεγμένη';
$string['selectedcapabilitydoesntexit'] = 'Η τρέχουσα ρύθμιση απαιτεί την δυνατότητα ικανότητα ({$a}), η οποία δεν υπάρχει πια. Παρακαλούμε να την αλλάξετε και να αποθηκεύσετε τις αλλαγές.';
$string['selectservice'] = 'Επιλέξτε ένα service';
$string['selectspecificuser'] = 'Επιλέξτε έναν συγκεκριμένο χρήστη';
$string['selectspecificuserdescription'] = 'Προσθέστε τον web services χρηστη σαν ταυτοποιημένο χρήστη.';
$string['servicename'] = 'Όνομα service';
$string['servicenotavailable'] = 'Το web service δεν είναι διαθέσιμο (δεν υπάρχει ή είναι απενεργοποιημένο)';
$string['servicescustom'] = 'Προσαρμοσμένα services';
$string['serviceusers'] = 'Ταυτοποιημένοι χρήστες';
$string['serviceusersettings'] = 'Ρυθμίσεις χρήστη';
$string['serviceusersmatching'] = 'Ταύτιση ταυτοποιημένων χρηστών';
$string['serviceuserssettings'] = 'Αλλαγή ρυθμίσεων για τους ταυτοποιημένους χρήστες';
$string['shortnametaken'] = 'Το σύντομο όνομα χρησιμοποιείται για ένα άλλο service ({$a})';
$string['simpleauthlog'] = 'Σύνδεση απλού ελέγχου ταυτότητας';
$string['step'] = 'Βήμα';
$string['supplyinfo'] = 'Περισσότερες λεπτομέρειες';
$string['testauserwithtestclientdescription'] = 'Μιμηθείτε την εξωτερική πρόσβαση στο service χρησιμοποιώντας τον test client του web service. Πριν από αυτό, συνδεθείτε ως χρήστης με την δυνατότητα moodle/webservice:createtoken και αποκτήστε το κλειδί ασφαλείας (token) μέσω της σελίδας προτιμήσεων του χρήστη. Θα χρησιμοποιήσετε αυτό το κλειδί με το test client. Στον test client, επιλέξτε επίσης ένα ενεργοποιημένο πρωτόκολλο με το έλεγχο ταυτότητας token . <strong>ΠΡΟΕΙΔΟΠΟΙΗΣΗ: Οι συναρτήσεις που θα δοκιμάσετε θα εκτελεστούν για αυτόν τον χρήστη, οπότε να είστε προσεκτικοί τι θα επιλέξετε να δοκιμάσετε</ strong>!';
$string['testclient'] = 'Web service test client';
$string['testclientdescription'] = '* Ο web service test client <strong>εκτελεί</strong> τις συναρτήσεις <strong>ΠΡΑΓΜΑΤΙΚΑ</strong>. Μην δοκιμάζετε συναρτήσεις που δεν γνωρίζετε. <br/>* Όλες οι υπαρχουσες συναρτήσεις του web service δεν έχουν ακόμα υλοποιηθεί σε αυτόν τον test client. <br/>* Για να ελέγξετε ότι ένας χρήστης δεν έχει πρόσβαση σε κάποιες συναρτήσεις, μπορείτε να δοκιμάσετε τις συναρτήσεις που δεν επιτρέψατε.<br/>* Για να δείτε πιο περιγραφικά debugging μηνύματα θέστε το επίπεδο σε <strong>{$a->mode}</strong> στο {$a->atag}<br/>* Προσπελάστε το {$a->amfatag}.';
$string['testwithtestclient'] = 'Δοκιμάστε το service';
$string['testwithtestclientdescription'] = 'Μιμηθείτε την εξωτερική πρόσβαση στο service χρησιμοποιώντας τον test client του web service. Χρησιμοποιήστε ένα ενεργοποιημένο πρωτόκολλο με τον έλεγχο ταυτότητας με token. <strong>ΠΡΟΕΙΔΟΠΟΙΗΣΗ: Οι συναρτήσεις που θα δοκιμάσετε ΘΑ ΕΚΤΕΛΕΣΤΟΥΝ, οπότε να είστε προσεκτικοί τι θα επιλέξετε να δοκιμάσετε</ strong>!';
$string['token'] = 'Κλειδί (Token)';
$string['tokenauthlog'] = 'Ταυτοποίηση κλειδιού (token)';
$string['tokencreatedbyadmin'] = 'Μπορεί να γίνει η επαναφορά του μόνο από τον διαχειριστή (*)';
$string['tokencreator'] = 'Δημιουργός';
$string['unknownoptionkey'] = 'Άγνωστο πλήκτρο επιλογής ({$a})';
$string['unnamedstringparam'] = 'Μια παράμετρος string είναι μη προσδιορισμένη.';
$string['updateusersettings'] = 'Ενημέρωση';
$string['uploadfiles'] = 'Μπορεί να ανεβάσει αρχεία';
$string['uploadfiles_help'] = 'Αν ενεργοποιηθεί, κάθε χρήστης θα μπορεί να ανεβάσει αρχεία με τα κλειδιά ασφαλείας του στο δικό τους προσωπικό χώρο. Ισχύουν τα όρια αρχείων.';
$string['userasclients'] = 'Οι χρήστες ως πελάτες με κλειδί (token)';
$string['userasclientsdescription'] = 'Τα ακόλουθα βήματα θα σας βοηθήσουν να ρυθμίσετε το Moodle web service για τους χρήστες, σαν πελάτες. Τα βήματα αυτά βοηθούν επίσης να ρυθμίσετε το προτεινόμενο token (κλειδιά ασφαλείας) μέθοδο ταυτοποίησης. Στην περίπτωση αυτή, ο χρήστης θα δημιουργήσει το κλειδί του από τη σελίδα κλειδιών ασφαλείας μέσω της σελίδας των προτιμήσεων του.';
$string['usermissingcaps'] = 'Απούσες δυνατότητες: {$a}';
$string['usernameorid'] = 'Όνομα χρήστη / κωδικός χρήστη';
$string['usernameoridnousererror'] = 'Δεν βρέθηκαν χρήστες με αυτό το όνομα χρήστη / κωδικό χρήστη.';
$string['usernameoridoccurenceerror'] = 'Περισσότεροι από ένας χρήστης βρέθηκαν με αυτό το όνομα χρήστη. Παρακαλώ εισάγετε τον κωδικό χρήστη.';
$string['usernameorid_help'] = 'Εισάγετε ένα όνομα χρήστη ή ένα κωδικό χρήστη.';
$string['usernotallowed'] = 'Ο χρήστης δεν επιτρέπεται για το service αυτό. Πρώτα θα πρέπει να επιτραπεί ο χρήστης στη {$a} από τη σχετική σελίδα διαχείρισης.';
$string['usersettingssaved'] = 'Αποθηκεύτηκαν οι ρυθμίσεις χρήστη';
$string['validuntil_help'] = 'Εάν οριστεί, η υπηρεσία θα απενεργοποιηθεί μετά την ημερομηνία αυτή για αυτόν τον χρήστη.';
$string['webservice'] = 'Web service';
$string['webservices'] = 'Web services';
$string['webservicesoverview'] = 'Επισκόπηση';
$string['webservicetokens'] = 'Κλειδιά web service';
$string['wrongusernamepassword'] = 'Λάθος όνομα ή κωδικός πρόσβασης';
$string['wsaccessuserdeleted'] = 'Δεν επιτρέπεται η πρόσβαση στο web service για το διεγραμμένο όνομα πρόσβασης:{$a}';
$string['wsaccessuserexpired'] = 'Δεν επιτρέπεται η πρόσβαση στο web service για το όνομα πρόσβασης:{$a} το οποίο έχει ληγμένο κωδικό πρόσβασης';
$string['wsaccessusernologin'] = 'Δεν επιτρέπεται η πρόσβαση στο web service για το όνομα πρόσβασης:{$a} το οποίο δεν έχει κάνει login.';
$string['wsaccessusersuspended'] = 'Δεν επιτρέπεται η πρόσβαση στο web service για το ανενεργό όνομα πρόσβασης:{$a}';
$string['wsaccessuserunconfirmed'] = 'Δεν επιτρέπεται η πρόσβαση στο web service για το μη επιβεβαιωμένο όνομα πρόσβασης:{$a}';
$string['wsclientdoc'] = 'Τεκμηρίωση του Moodle web service client';
$string['wsdocapi'] = 'Τεκμηρίωση του API';
$string['wsdocumentation'] = 'Τεκμηρίωση του Web service';
$string['wsdocumentationdisable'] = 'Η τεκμηρίωση του Web service είναι απενεργοποιημένη.';
$string['wsdocumentationintro'] = 'Για να δημιουργήσετε έναν client σας συμβουλεύουμε να διαβάσετε το {$a->doclink}';
$string['wsdocumentationlogin'] = 'ή δώστε το όνομα και τον κωδικό πρόσβασής σας για το web service:';
$string['wspassword'] = 'Κωδικός πρόσβασης web service';
$string['wsusername'] = 'Όνομα πρόσβασης web service';
