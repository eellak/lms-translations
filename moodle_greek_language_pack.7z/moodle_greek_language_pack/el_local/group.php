<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage group
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addedby'] = 'Προστέθηκε από {$a}';
$string['addgroup'] = 'Προσθήκη χρήστη στην ομάδα';
$string['enrolmentkeyalreadyinuse'] = 'Το κλειδί εγγραφής χρησιμοποιείται ήδη από άλλη ομάδα.';
$string['enrolmentkey_help'] = 'Ένα κλειδί εγγραφής περιορίζει την πρόσβαση μόνο σε αυτούς που έχουν το κλειδί. Εάν προσδιοριστεί ένα ομαδικό κλειδί εγγραφής, τότε η εισαγωγή αυτού του κλειδιού όχι μόνο θα επιτρέψει την είσοδο του χρήστη στο μάθημα, αλλά θα τον κάνει αυτόματα και μέλος της ομάδας. Σημείωση: Το ομαδικό κλειδί εγγραφής πρέπει να ενεργοποιηθεί στις ρυθμίσεις της αυτόματης εγγραφής και πρέπει να έχει οριστεί και ένα κλειδί εγγραφής.';
$string['errorremovenotpermitted'] = 'Δεν έχετε άδεια να αφαιρέσετε το μέλος της ομάδας {$a}, το οποίο έχει προστεθεί αυτόματα';
$string['eventgroupcreated'] = 'Δημιουργήθηκε η ομάδα';
$string['eventgroupdeleted'] = 'Διαγράφηκε η ομάδα';
$string['eventgroupingcreated'] = 'Δημιουργήθηκε η ομαδοποίηση';
$string['eventgroupingdeleted'] = 'Διαγράφηκε η ομαδοποίηση';
$string['eventgroupingupdated'] = 'Ενημερώθηκε η ομαδοποίηση';
$string['eventgroupmemberadded'] = 'Προστέθηκε το μέλος στην ομάδα';
$string['eventgroupmemberremoved'] = 'Αφαιρέθηκε το μέλος από την ομάδα';
$string['eventgroupupdated'] = 'Ενημερώθηκε η ομάδα';
$string['groupaddedtogroupingsuccesfully'] = 'Η ομάδα {$a->groupname} προστέθηκε στην ομαδοποίηση {$a->groupingname} επιτυχώς';
$string['groupingaddedsuccesfully'] = 'Η ομαδοποίηση {$a} προστέθηκε επιτυχώς';
$string['groupingsection'] = 'Πρόσβαση ομαδοποίησης';
$string['groupingsection_help'] = 'Μια ομαδοποίηση είναι μια συλλογή από ομάδες μέσα σε ένα μάθημα. Εάν επιλεγεί εδώ μια ομαδοποίηση, μόνο οι μαθητές που ανήκουν σε ομάδες της ομαδοποίησης, θα έχουν πρόσβαση σε αυτόν τον τομέα.';
$string['importgroups_help'] = 'Οι ομάδες μπορούν να εισαχθούν με αρχείο κειμένου. Η μορφοποίηση του αρχείου θα πρέπει να είναι ως ακολούθως: * Κάθε γραμμή του αρχείου θα περιέχει μια εγγραφή * Κάθε εγγραφή είναι μια σειρά από δεδομένα χωρισμένα με κόμμα* Η πρώτη εγγραφή περιέχει μόνο μια λίστα από ονόματα πεδίων που ορίζουν την μορφοποίηση του υπόλοιπου αρχείου. * Υποχρεωτικό όνομα πεδίου είναι groupname * Τα προαιρετικά πεδία είναι τα description, enrolmentkey, picture, hidepicture';
$string['mygroups'] = 'Οι ομάδες μου';
$string['namingscheme_help'] = 'Το σύμβολο @ μπορεί να χρησιμοποιηθεί για την δημιουργία ομάδων με ονόματα που περιέχουν γράμματα. Για παράδειγμα το Ομάδα @, θα δημιουργήσει ομάδες με το όνομα Ομάδα Α, Ομάδα Β, Ομάδα Γ, ... Το σύμβολο # μπορεί να χρησιμοποιηθεί για την δημιουργία ομάδων με ονόματα που περιέχουν νούμερα. Για παράδειγμα το Ομάδα #, θα δημιουργήσει ομάδες με το όνομα Ομάδα 1, Ομάδα 2, Ομάδα 3, ...';
$string['nogrouping'] = 'Καμία ομαδοποίηση';
$string['notingroup'] = 'Αγνοήστε τους χρήστες σε ομάδες';
$string['othergroups'] = 'Άλλες ομάδες';
$string['removefromgroup'] = 'Διαγραφή χρήστη από την ομάδα {$a}';
$string['removefromgroupconfirm'] = 'Θέλετε πραγματικά να αφαιρέσετε τον χρήστη "{$a->user}" από την ομάδα "{$a->group}";';
$string['selectfromgroup'] = 'Επιλέξετε μέλη από την ομάδα';
$string['selectfromgrouping'] = 'Επιλέξετε μέλη από την ομαδοποίηση';
