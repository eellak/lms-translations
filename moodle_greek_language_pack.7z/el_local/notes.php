<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage notes
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['eventnotecreated'] = 'Η σημείωση δημιουργήθηκε';
$string['eventnotedeleted'] = 'Η σημείωση διαγράφηκε';
$string['eventnotesviewed'] = 'Οι σημειώσεις προβλήθηκαν';
$string['eventnoteupdated'] = 'Η σημείωση ενημερώθηκε';
$string['invaliduserid'] = 'Άκυρη ταυτότητα χρήστη: {$a}';
$string['myprofileownnotes'] = 'Οι σημειώσεις μου';
$string['page-notes-index'] = 'Αρχική σελίδα σημειώσεων';
$string['page-notes-x'] = 'Όλες οι σελίδες σημειώσεων';
$string['publishstate_help'] = 'Το πλαίσιο μιας σημείωσης καθορίζει ποιος μπορεί να δει τη σημείωση. * Προσωπική - Η σημείωση θα είναι ορατή μόνο σε εσάς * Μάθημα - Η σημείωση αυτή θα είναι ορατή στους εκπαιδευτικούς σε αυτό το μάθημα * Ιστοσελίδα - Η σημείωση αυτή θα είναι ορατή στους εκπαιδευτικούς σε όλα τα μαθήματα';
$string['selectnotestate'] = 'Επιλέξτε την κατάσταση της σημείωσης';
