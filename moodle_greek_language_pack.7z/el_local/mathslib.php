<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage mathslib
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['anunexpectederroroccured'] = 'παρουσιάστηκε μη αναμενόμενο σφάλμα';
$string['cannotassigntoconstant'] = 'δεν μπορεί να γίνει ανάθεση τιμής στη σταθερά  \'{$a}\'';
$string['cannotredefinebuiltinfunction'] = 'δεν μπορεί να επαναπροσδιοριστεί η ενσωματωμένη συνάρτηση \'{$a}()\'';
$string['divisionbyzero'] = 'διαίρεση με το μηδέν';
$string['expectingaclosingbracket'] = 'περίμενα δεξί bracket';
$string['illegalcharactergeneral'] = 'μη επιτρεπτός χαρακτήρας \'{$a}\'';
$string['illegalcharacterunderscore'] = 'μη επιτρεπτός χαρακτήρας \'_\'';
$string['implicitmultiplicationnotallowed'] = 'περίμενα τελεστή, δεν επιτρέπεται ο έμμεσος πολλαπλασιασμός.';
$string['internalerror'] = 'εσωτερικό σφάλμα';
$string['operatorlacksoperand'] = 'ο τελεστής \'{$a}\' δεν έχει τελεστέο';
$string['undefinedvariable'] = 'απροσδιόριστη μεταβλητή  \'{$a}\'';
$string['undefinedvariableinfunctiondefinition'] = 'απροσδιόριστη μεταβλητή \'{$a}\' στον ορισμό της συνάρτησης';
$string['unexpectedclosingbracket'] = 'μη αναμενόμενο δεξί bracket';
$string['unexpectedcomma'] = 'μη αναμενόμενο κόμμα';
$string['unexpectedoperator'] = 'μη αναμενόμενος τελεστής \'{$a}\'';
$string['wrongnumberofarguments'] = 'λανθασμένος αριθμός ορισμάτων (δόθηκαν {$a->given} , αναμένονται {$a->expected})';
