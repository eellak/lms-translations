<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage grading
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activemethodinfo'] = 'Η μέθοδος \'{$a->method}\' είναι επιλεγμένη σας η ενεργή μέθοδος βαθμολόγησης για την περιοχή \'{$a->area}\'';
$string['activemethodinfonone'] = 'Δεν έχει επιλεγεί προηγμένη μέθοδος βαθμολόγησης για την περιοχή \'{$a->area}\'. Θα χρησιμοποιηθεί η απλή, άμεση βαθμολόγηση.';
$string['changeactivemethod'] = 'Αλλαγή ενεργής μεθόδου βαθμολόγησης';
$string['clicktoclose'] = 'κάντε κλικ για το κλείσετε';
$string['exc_gradingformelement'] = 'Αδυναμία αρχικοποίησης στοιχείου φόρμας βαθμολόγησης';
$string['formnotavailable'] = 'Έχει επιλεγεί η χρήση προηγμένης μεθόδου βαθμολόγησης αλλά η φόρμα βαθμολόγησης δεν είναι ακόμα διαθέσιμη. Μπορεί να χρειάζεται να ορίσετε τον σχετικό σύνδεσμο στο μπλοκ της Διαχείρισης.';
$string['gradingformunavailable'] = 'Παρακαλούμε σημειώστε: η προηγμένη φόρμα βαθμολόγησης δεν είναι έτοιμη αυτή τη στιγμή. Θα χρησιμοποιηθεί η απλή μέθοδος βαθμολόγησης μέχρις ότου η φόρμα να γίνει έγκυρη.';
$string['gradingmanagement'] = 'Προηγμένη βαθμολόγηση';
$string['gradingmanagementtitle'] = 'Προηγμένη βαθμολόγηση: {$a->component} ({$a->area})';
$string['gradingmethod'] = 'Μέθοδος βαθμολόγησης';
$string['gradingmethodnone'] = 'Απλή άμεση βαθμολόγηση';
$string['gradingmethods'] = 'Μέθοδοι βαθμολόγησης';
$string['gradingmethod_help'] = 'Επιλέξτε την προηγμένη μέθοδο βαθμολόγησης που θα πρέπει να χρησιμοποιηθεί για τον υπολογισμό των βαθμών στο συγκεκριμένο πλαίσιο. Για να απενεργοποιήσετε την προηγμένη βαθμολόγηση και να επιστρέψετε στο προεπιλεγμένο μηχανισμό βαθμολόγησης, επιλέξτε "Απλή άμεση βαθμολόγηση".';
$string['manageactionclone'] = 'Δημιουργία νέας φόρμας βαθμολόγησης από ένα πρότυπο.';
$string['manageactiondelete'] = 'Σβήστε την επί του παρόντος ορισμένη φόρμα.';
$string['manageactiondeleteconfirm'] = 'Πρόκειται να διαγράψετε τη φόρμα βαθμολόγησης \'{$a->formname}\' και όλες τις συναφείς πληροφορίες από το \'{$a->component} ({$a->area})\'. Παρακαλώ βεβαιωθείτε ότι έχετε κατανοήσει τις ακόλουθες συνέπειες: * Δεν υπάρχει κανένας τρόπος να αναιρέσετε αυτή τη λειτουργία. * Μπορείτε να μεταβείτε σε μια άλλη μέθοδο βαθμολόγησης, συμπεριλαμβανομένης της "απλής άμεσης βαθμολόγησης" χωρίς τη διαγραφή αυτής της φόρμας. * Όλες οι πληροφορίες σχετικά με το πώς συμπληρώνονται οι φόρμες βαθμολόγησης θα χαθούν. * Οι υπολογισμένοι βαθμοί που έχουν ήδη αποθηκευτεί στο βαθμολόγιο δεν θα επηρεαστούν. Ωστόσο, η εξήγηση για το πώς υπολογίστηκαν δεν θα είναι διαθέσιμη. * Αυτή η λειτουργία δεν επηρεάζει ενδεχόμενα αντίγραφα αυτής της φόρμας σε άλλες δραστηριότητες.';
$string['manageactiondeletedone'] = 'Αυτή η φόρμα διαγράφηκε επιτυχώς';
$string['manageactionedit'] = 'Τροποποίηση του τρέχοντος ορισμού της φόρμας';
$string['manageactionnew'] = 'Ορισμός μια νέας φόρμας βαθμολόγησης εκ του μηδενός';
$string['manageactionshare'] = 'Δημοσίευση της φόρμας σας ένα νέο πρότυπο';
$string['manageactionshareconfirm'] = 'Πρόκειται να αποθηκεύσετε ένα αντίγραφο της φόρμας βαθμολόγησης \'{$a}\' ως ένα νέο δημόσιο πρότυπο. Άλλοι χρήστες στο site σας, θα είναι σε θέση να δημιουργήσουν νέες φόρμες βαθμολόγησης στις δραστηριότητες τους από αυτό το πρότυπο.';
$string['manageactionsharedone'] = 'Η φόρμα αποθηκεύτηκε επιτυχώς σας πρότυπο.';
$string['noitemid'] = 'Δεν είναι δυνατή η βαθμολόγηση. Το αντικείμενο προς βαθμολόγηση δεν υπάρχει.';
$string['nosharedformfound'] = 'Δεν βρέθηκε πρότυπο';
$string['searchownforms'] = 'περιλαμβάνει τις δικές μου φόρμες';
$string['searchtemplate'] = 'Αναζήτηση φορμών βαθμολόγησης';
$string['searchtemplate_help'] = 'Μπορείτε να ψάξετε για μια φόρμα βαθμολόγησης και να τη χρησιμοποιήσετε ως πρότυπο για τη νέα φόρμα βαθμολόγησης εδώ. Απλά πληκτρολογήστε τις λέξεις που πρέπει να εμφανίζονται κάπου στο όνομα της φόρμας, την περιγραφή της ή το ίδιο το κείμενο της φόρμα. Για να αναζητήσετε μια φράση, βάλτε διπλά εισαγωγικά (") στον όρο αναζήτησης. Από προεπιλογή, μόνο οι φόρμες βαθμολόγησης που έχουν αποθηκευτεί ως δημόσια πρότυπα περιλαμβάνονται στα αποτελέσματα της αναζήτησης. Μπορείτε επίσης να συμπεριλάβετε όλες τις δικές σας φόρμες βαθμολόγησης στα αποτελέσματα αναζήτησης. Με αυτό τον τρόπο, μπορείτε απλά να χρησιμοποιήσετε ξανά τις φόρμες βαθμολόγησής σας χωρίς να τις μοιραστείτε. Μόνο οι φόρμες που φέρουν ως σήμανση το  «Έτοιμο προς χρήση» μπορούν να χρησιμοποιηθούν εκ νέου με αυτόν τον τρόπο.';
$string['statusdraft'] = 'Προσχέδιο';
$string['statusready'] = 'Έτοιμο για χρήση';
$string['templatedelete'] = 'Διαγραφή';
$string['templatedeleteconfirm'] = 'Πρόκειται να σβήσετε το κοινό πρότυπο {$a}\'. Η διαγραφή ενός πρότυπου δεν επηρεάζει τις υπάρχουσες φόρμες που δημιουργήθηκαν από αυτό.';
$string['templateedit'] = 'Τροποποίηση';
$string['templatepick'] = 'Χρήση αυτού του πρότυπου';
$string['templatepickconfirm'] = 'Θέλετε να χρησιμοποιήσετε τη φόρμα \'{$a->formname}\' σαν πρότυπο για τη νέα φόρμα βαθμολόγησης στο \'{$a->component} ({$a->area})\';';
$string['templatepickownform'] = 'Χρήση αυτής της φόρμας σαν πρότυπο';
$string['templatesource'] = 'Τοποθεσία: {$a->component} ({$a->area})';
$string['templatetypeown'] = 'Ιδιόκτητη φόρμα';
$string['templatetypeshared'] = 'Κοινό πρότυπο';
