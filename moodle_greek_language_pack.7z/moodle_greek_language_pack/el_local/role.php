<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage role
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['archetypefrontpage'] = 'ΑΡΧΕΤΥΠΟ: Επισκέπτης';
$string['archetypestudent'] = 'ΑΡΧΕΤΥΠΟ: Φοιτητής';
$string['archetypeuser'] = 'ΑΡΧΕΤΥΠΟ: πιστοποιημένος χρήστης';
$string['assignedroles'] = 'Ανατεθειμένοι ρόλοι';
$string['assignrole'] = 'Ανάθεση ρόλου';
$string['badges:awardbadge'] = 'Επιβράβευση χρήστη με ένα σήμα';
$string['badges:configurecriteria'] = 'Ρύθμιση / Επεξεργασία κριτηρίων για την απόδοση ενός σήματος';
$string['badges:configuredetails'] = 'Ρύθμιση / Επεξεργασία λεπτομερειών σήματος';
$string['badges:configuremessages'] = 'Διαμόρφωση μηνυμάτων σήματος';
$string['badges:createbadge'] = 'Δημιουργία / αντιγραφή σημάτων';
$string['badges:deletebadge'] = 'Διαγραφή σημάτων';
$string['badges:earnbadge'] = 'Κερδίστε σήμα';
$string['badges:manageglobalsettings'] = 'Διαχειριστείτε τις γενικές ρυθμίσεις των σημάτων';
$string['badges:manageownbadges'] = 'Δείτε και διαχειριστείτε τα σήματα που έχετε κερδίσει';
$string['badges:viewawarded'] = 'Δείτε τους χρήστες που κέρδισαν ένα συγκεκριμένο σήμα, χωρίς να είναι σε θέση να απονείμουν κάποιο σήμα';
$string['badges:viewbadges'] = 'Δείτε τα διαθέσιμα σήματα, χωρίς να τα κερδίσετε';
$string['badges:viewotherbadges'] = 'Δείτε τα δημόσια σήματα, στο προφίλ άλλων χρηστών';
$string['blog:associatecourse'] = 'Η δυνατότητα αυτή έχει καταργηθεί και δεν κάνει τίποτα.';
$string['blog:associatemodule'] = 'Η δυνατότητα αυτή έχει καταργηθεί και δεν κάνει τίποτα.';
$string['blog:search'] = 'Αναζήτηση καταχωρήσεων ιστολογίου';
$string['confirmaddadmin'] = 'Θέλετε πραγματικά να προσθέσετε το χρήστη <strong> {$a} </ strong> ως νέο διαχειριστή του δικτυακού τόπου;';
$string['confirmdeladmin'] = 'Θέλετε πραγματικά να διαγράψετε τον χρήστη <strong> {$a} </ strong> από τον κατάλογο των διαχειριστών της ιστοσελίδας;';
$string['confirmroleprevent'] = 'Θέλετε πραγματικά να αφαιρέσετε τον ρόλο <strong>{$a->role}</strong> από τη λίστα των επιτρεπόμενων ρόλων για την ικανότητά {$a->cap} στο πλαίσιο {$a->context};';
$string['confirmroleunprohibit'] = 'Θέλετε πραγματικά να αφαιρέσετε τον ρόλο <strong>{$a->role}</strong> από τη λίστα των απαγορευμένων ρόλων για την ικανότητά {$a->cap} στο πλαίσιο {$a->context};';
$string['confirmunassign'] = 'Είστε σίγουροι ότι θέλετε να καταργήσετε αυτόν τον ρόλο από αυτόν τον χρήστη;';
$string['confirmunassignno'] = 'Ακύρωση';
$string['confirmunassigntitle'] = 'Επιβεβαίωση αλλαγής ρόλου';
$string['confirmunassignyes'] = 'Αφαίρεση';
$string['course:ignorefilesizelimits'] = 'Χρησιμοποιήστε αρχεία μεγαλύτερα από κάθε περιορισμό μεγέθους αρχείου';
$string['course:isincompletionreports'] = 'Να αναγράφονται στις τελικές αναφορές';
$string['course:markcomplete'] = 'Σημείωση χρηστών ως ολοκληρωμένους, στην παρακολούθηση του μαθήματος';
$string['course:movesections'] = 'Μεταφορά τμημάτων';
$string['course:reviewotherusers'] = 'Επανεξέταση άλλων χρηστών';
$string['course:viewsuspendedusers'] = 'Προβολή ανεσταλμένων χρηστών';
$string['customroledescription'] = 'Προσαρμοσμένη περιγραφή';
$string['customroledescription_help'] = 'Οι περιγραφές των βασικών ρόλων μεταφράζεται αυτόματα εάν η προσαρμοσμένη περιγραφή είναι άδεια.';
$string['customrolename'] = 'Πλήρες προσαρμοσμένο όνομα';
$string['customrolename_help'] = 'Τα ονόματα των τυποποιημένων ρόλων μεταφράζονται αυτόματα αν το προσαρμοσμένο όνομα είναι άδειο. Θα πρέπει να δώσετε ένα πλήρες όνομα για όλους τους προσαρμοσμένους ρόλους.';
$string['eventroleallowassignupdated'] = 'Επιτρέψτε την ανάθεση ρόλων';
$string['eventroleallowoverrideupdated'] = 'Επιτρέψτε την αντικατάσταση ρόλων';
$string['eventroleallowswitchupdated'] = 'Επιτρέψτε την αλλαγή ρόλων';
$string['eventroleassigned'] = 'Ο ρόλος αποδόθηκε';
$string['eventrolecapabilitiesupdated'] = 'Ενημερώθηκαν οι δυνατότητες του ρόλου';
$string['eventroledeleted'] = 'Ο ρόλος διαγράφηκε';
$string['eventroleunassigned'] = 'Ο ρόλος αφαιρέθηκε';
$string['export'] = 'Εξαγωγή';
$string['filter:manage'] = 'Διαχειριστείτε τις ρυθμίσεις του τοπικού φίλτρου';
$string['frontpageuserdescription'] = 'Όλοι οι συνδεδεμένοι χρήστες στο μάθημα frontpage.';
$string['grade:managegradingforms'] = 'Διαχειριστείτε τις μεθόδους προηγμένης βαθμολόγησης';
$string['grade:managesharedforms'] = 'Διαχειριστείτε τα πρότυπα φορμών της προηγμένης βαθμολόγησης';
$string['grade:sharegradingforms'] = 'Μοιραστείτε τη φόρμα προηγμένης βαθμολόγησης ως πρότυπο';
$string['invalidpresetfile'] = 'Μη έγκυρο αρχείο ορισμού ρόλου';
$string['mainadmin'] = 'Κύριος διαχειριστής';
$string['mainadminset'] = 'Ορισμός κεντρικού διαχειριστή';
$string['my:configsyspages'] = 'Διαμορφώστε τα πρότυπα του συστήματος για τις σελίδες myMoodle';
$string['my:manageblocks'] = 'Διαχείριση των μπλοκ της σελίδας myMoodle';
$string['norole'] = 'Κανένας ρόλος';
$string['noroles'] = 'Κανένας ρόλος';
$string['resettingrole'] = 'Επαναφορά ρόλου \'{$a}\'';
$string['roleallowheader'] = 'Επιτρέψτε ρόλο:';
$string['roleallowinfo'] = 'Επιλέξτε ένα ρόλο να προστεθεί στον κατάλογο των επιτρεπόμενων ρόλων στο πλαίσιο  {$a->context}, capability {$a->cap}:';
$string['roleincontext'] = '{$a->role} σε {$a->context}';
$string['roleprohibitinfo'] = 'Επιλέξτε ένα ρόλο να προστεθεί στον κατάλογο των απαγορευμένων ρόλων στο πλαίσιο {$a->context}, ικανότητα {$a->cap}:';
$string['rolerepreset'] = 'Χρησιμοποιήστε προκαθορισμένο ρόλο';
$string['roleresetdefaults'] = 'Προεπιλογές';
$string['roleresetrole'] = 'Χρησιμοποιήστε ρόλο ή αρχέτυπο';
$string['rolerisks'] = 'Ρόλος κινδύνων';
$string['roleselect'] = 'Επιλογή ρόλου';
$string['rolesforuser'] = 'Ρόλοι για τον χρήστη {$a}';
$string['roleshortname_help'] = 'Το σύντομο όνομα του ρόλου είναι ένα αναγνωριστικό ρόλου, χαμηλού επίπεδου στο οποίο επιτρέπονται μόνο ASCII αλφαριθμητικοί χαρακτήρες. Μην αλλάζετε τα σύντομα ονόματα των τυποποιημένων ρόλων.';
$string['site:forcelanguage'] = 'Παράκαμψη μαθήματος γλώσσας';
$string['site:viewuseridentity'] = 'Δείτε την πλήρη ταυτότητα του χρήστη στις λίστες';
$string['tag:flag'] = 'Χαρακτηρίστε τις ετικέτες σαν ανάρμοστες';
$string['thisnewrole'] = 'Αυτός ο νέος ρόλος';
$string['unassignarole'] = 'Αφαίρεση ρόλου {$a}';
$string['unassignconfirm'] = 'Θέλετε πραγματικά να αφαιρέσετε τον ρόλο "{$a->role}" από τον χρήστη "{$a->user}";';
$string['user:ignoreuserquota'] = 'Αγνοήστε το επιτρεπτό όριο του χρήστη';
$string['user:viewlastip'] = 'Δείτε την τελευταία διεύθυνση IP του χρήστη';
