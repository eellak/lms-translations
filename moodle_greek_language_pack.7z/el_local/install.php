<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage install
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cliadminemail'] = 'Διεύθυνση ηλεκτρονικού ταχυδρομείου νέου διαχειριστή';
$string['cliadminpassword'] = 'Κωδικός πρόσβασης νέου διαχειριστή';
$string['cliadminusername'] = 'Όνομα πρόσβασης διαχειριστή';
$string['clialreadyconfigured'] = 'Το αρχείο ρυθμίσεων config.php υπάχει ήδη. Χρησιμοποιήστε το αρχείο admin/cli/install_database.php για να εγκαταστήσετε το  Moodle σε αυτόν τον ιστότοπο.';
$string['clialreadyinstalled'] = 'Το αρχείο ρυθμίσεων config.php υπάχει ήδη. Χρησιμοποιήστε το αρχείο admin/cli/install_database.php για να αναβαθμίσετε το  Moodle σε αυτόν τον ιστότοπο.';
$string['cliinstallfinished'] = 'Η εγκατάσταση ολοκληρώθηκε επιτυχώς.';
$string['cliinstallheader'] = 'Πρόγραμμα εγκατάστασης Moodle {$a} σε γραμμή εντολών';
$string['climustagreelicense'] = 'Σε μη διαδραστική λειτουργία θα πρέπει να αποδεχτείτε την άδεια, χρησιμοποιόντας την επιλογή  --agree-license';
$string['clitablesexist'] = 'Οι πίνακες της βάσης δεδομένων υπάρχουν ήδη, η εγκατάσταση CLI δεν μπορεί να συνεχιστεί.';
$string['databaseport'] = 'Πόρτα βάσης δεδομένων';
$string['datarootpermission'] = 'Δικαιώματα σε καταλόγους δεδομένων';
$string['dbport'] = 'Πόρτα';
$string['nativemariadb'] = 'MariaDB (native/mariadb)';
$string['nativemariadbhelp'] = '<p>Στη βάση δεδομένων αποθηκεύονται οι περισσότερες ρυθμίσεις και τα δεδομένα του Moodle και εδώ πρέπει να οριστούν.</p> <p>Το όνομα της βάσης δεδομένων, το όνομα χρήστη και ο κωδικός πρόσβασης είναι υποχρεωτικά πεδία, το πρόθεμα των πινάκων είναι προαιρετικό.</p> <p>Εάν η βάση δεδομένων δεν υπάρχει και ο χρήστης που έχει χρησιμοποιθεί έχει τα απαραίτητα δικαιώματα, το Moodle θα προσπαθήσει να δημιουργήσει μια νέα βάση δεδομένων με τα κατάλληλα δικαιώματα και ρυθμίσεις.</p> <p>Αυτός ο οδηγός δεν είναι συμβατός με   legacy MyISAM engine.</p>';
$string['nativemssql'] = 'SQL*Server FreeTDS (native/mssql)';
$string['nativemssqlhelp'] = 'Τώρα πρέπει να ρυθμίσετε την βάση δεδομένων που θα αποθηκεύονται τα περισσότερα δεδομένα του Moodle. Αυτή η βάση δεδομένων πρέπει να υπάρχει ήδη και να έχει όνομα και κωδικό πρόσβαση. Το πρόθεμα των πινάκων είναι υποχρεωτικό.';
$string['nativeoci'] = 'Oracle (native/oci)';
$string['nativeocihelp'] = 'Τώρα πρέπει να ρυθμίσετε την βάση δεδομένων που θα αποθηκεύονται τα περισσότερα δεδομένα του Moodle. Αυτή η βάση δεδομένων πρέπει να υπάρχει ήδη και να έχει όνομα και κωδικό πρόσβαση. Το πρόθεμα των πινάκων είναι υποχρεωτικό.';
$string['nativesqlsrv'] = 'SQL*Server Microsoft (native/sqlsrv)';
$string['nativesqlsrvhelp'] = 'Τώρα πρέπει να ρυθμίσετε την βάση δεδομένων που θα αποθηκεύονται τα περισσότερα δεδομένα του Moodle. Αυτή η βάση δεδομένων πρέπει να υπάρχει ήδη και να έχει όνομα και κωδικό πρόσβαση. Το πρόθεμα των πινάκων είναι υποχρεωτικό.';
$string['nativesqlsrvnodriver'] = 'Οι οδηγοί της Microsoft για SQL Server για PHP δεν είναι εγκατεστημένοι ή δεν είναι σωστά ρυθμισμένοι.';
$string['nativesqlsrvnonwindows'] = 'Οι οδηγοί της Microsoft για SQL Server για PHP είναι διαθέσιμοι μόνο για το λειτουργικό σύστημα Windows.';
