<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage availability
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['condition_group'] = 'Σύνολο περιορισμών';
$string['condition_group_info'] = 'Προσθέστε ένα σύνολο από ένθετους περιορισμούς για να εφαρμόσετε σύνθετη λογική.';
$string['error_list_nochildren'] = 'Τα σύνολα των περιορισμών θα πρέπει να περιέχουν τουλάχιστον έναν όρο.';
$string['hidden_all'] = 'Να αποκρύπτονται εντελώς αν ο χρήστης δεν πληροί τις προϋποθέσεις';
$string['hidden_individual'] = 'Να αποκρύπτονται εντελώς αν ο χρήστης δεν πληροί αυτή την προϋπόθεση';
$string['hidden_marker'] = '(Διαφορετικά να αποκρύπτονται)';
$string['hide_verb'] = 'Απόκρυψη';
$string['itemheading'] = '{$a->number} {$a->type} περιορισμός';
$string['item_unknowntype'] = 'Οι περιορισμοί αυτοί χρησιμοποιούν ένα plugin το οποίο δεν είναι πλέον διαθέσιμο (εάν είναι εντάξει να αφαιρέσετε αυτόν τον περιορισμό, διαγράψτε το παρακάτω)';
$string['label_multi'] = 'Απαιτούμενοι περιορισμοί';
$string['listheader_sign_before'] = 'Φοιτητής';
$string['listheader_single'] = 'ταιριάζει με το ακόλουθο';
$string['list_and'] = 'Όλα :';
$string['list_and_hidden'] = 'Όλα (Να αποκρύπτονται διαφορετικά):';
$string['list_or_hidden'] = 'Οποιαδήποτε από (Αλλιώς αποκρύπτονται):';
$string['list_root_and'] = 'Δεν είναι διαθέσιμα, εκτός εάν:';
$string['list_root_and_hidden'] = 'Μη διαθέσιμα(αποκρύπτονται) εκτός εάν:';
$string['list_root_or'] = 'Μη διαθέσιμα εκτός εάν οποιαδήποτε από:';
$string['list_root_or_hidden'] = 'Μη διαθέσιμα(Να αποκρύπτονται) εκτός εάν οποιαδήποτε από:';
$string['missingplugin'] = 'Λείπει το pluginπεριορισμού';
$string['restrictbygroup'] = 'Προσθήκη ομάδας / ομαδοποίηση περιορισμού πρόσβασης';
$string['setheading'] = '{$a->number} σύνολο από {$a->count} περιορισμό(ούς)';
$string['shown_all'] = 'Εμφανίζονται σκιασμένες, εάν ο χρήστης δεν πληροί τις προϋποθέσεις';
$string['shown_individual'] = 'Εμφανίζονται σκιασμένες, εάν ο χρήστης δεν πληροί αυτή την προϋπόθεση';
$string['show_verb'] = 'Κάντε κλικ για να εμφανιστεί';
$string['unknowncondition'] = 'Άγνωστη προϋπόθεση (διαγραμμένη προϋπόθεση plugin )';
