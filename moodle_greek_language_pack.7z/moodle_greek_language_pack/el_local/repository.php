<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage repository
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accessiblefilepicker'] = 'Προσβάσιμος επιλογέας αρχείου';
$string['activitybackup'] = 'Αντίγραφο ασφαλείας της δραστηριότητας';
$string['addfiletext'] = 'Προσθήκη αρχείου';
$string['areacourseoverviewfiles'] = 'Περιληπτικά αρχεία μαθήματος';
$string['areamainfile'] = 'Κύριο αρχείο';
$string['areauserbackup'] = 'Αντίγραφο ασφαλείας χρήστη';
$string['attachedfiles'] = 'Επισυναπτόμενα αρχεία';
$string['automatedbackup'] = 'Αυτοματοποιημένα αντίγραφα ασφαλείας';
$string['backtodraftfiles'] = '&laquo; Επιστροφή στη διαχείριση των μη οριστικών αρχείων';
$string['cannotaccessparentwin'] = 'Εάν το παράθυρο γονέας είναι σε HTTPS, δεν μας επιτρέπεται να έχουμε πρόσβαση στο αντικείμενο window.opener, οπότε δεν μπορούμε να ανανεώσουμε το αποθετήριο για εσάς αυτόματα, αλλά εμείς ήδη πήρε τη συνεδρία σας, απλά πηγαίνετε πίσω στην επιλογή αρχείου και επιλέξτε ξανά το αποθετήριο, θα πρέπει να λειτουργεί τώρα.';
$string['cannotdelete'] = 'Το αρχείο δεν μπορεί να διαγραφεί';
$string['cannotdownload'] = 'Δεν είναι δυνατή η λήψη αυτού του αρχείου';
$string['cannotdownloaddir'] = 'Δεν είναι δυνατή η λήψη αυτού του φακέλου';
$string['configgetfiletimeout'] = 'Χρονικό όριο σε δευτερόλεπτα για τη λήψη ένα εξωτερικό αρχείο από το Moodle.';
$string['configsyncfiletimeout'] = 'Χρονικό όριο σε δευτερόλεπτα για τον συγχρονισμό του μεγέθους του εξωτερικού αρχείου.';
$string['configsyncimagetimeout'] = 'Χρονικό όριο σε δευτερόλεπτα για τη λήψη μιας εικόνας από ένα εξωτερικό αποθετήριο κατά τη διάρκεια ενός συγχρονισμού.';
$string['confirmdeletefilewithhref'] = 'Είστε σίγουροι ότι θέλετε να διαγράψετε αυτό το αρχείο; Υπάρχουν {$a} ψευδώνυμα / συντομεύσεις που χρησιμοποιούν αυτό το αρχείο ως πηγή τους. Αν προχωρήσετε, τότε αυτά τα ψευδώνυμα θα μετατραπούν σε αληθινά αντίγραφα.';
$string['confirmdeletefolder'] = 'Είστε σίγουροι ότι θέλετε να διαγράψετε αυτόν τον φάκελο; Όλα τα αρχεία και οι υποφάκελοι θα διαγραφούν.';
$string['confirmrenamefile'] = 'Είστε σίγουροι ότι θέλετε να μετονομάσετε / μετακινήσετε αυτό το αρχείο; Υπάρχουν {$a} ψευδώνυμα / συντομεύσεις που χρησιμοποιούν αυτό το αρχείο ως πηγή τους. Αν προχωρήσετε τότε αυτά τα ψευδώνυμα θα μετατραπούν σε αληθινά αντίγραφα.';
$string['confirmrenamefolder'] = 'Είστε σίγουροι ότι θέλετε να μετακινήσετε / μετονομάσετε τον φάκελο; Όλα τα ψευδώνυμα / συντομεύσεις που αναφέρονται σε αρχεία σε αυτόν το φάκελο, θα μετατραπούν σε αληθινά αντίγραφα.';
$string['continueuninstall'] = 'Συνέχεια';
$string['continueuninstallanddownload'] = 'Συνέχεια και λήψη';
$string['coursebackup'] = 'Αντίγραφα ασφαλείας μαθήματος';
$string['createfolder'] = 'Δημιουργία φακέλου';
$string['createfolderfail'] = 'Αποτυχία δημιουργίας φακέλου';
$string['createfoldersuccess'] = 'Επιτυχής δημουργία φακέλου';
$string['datecreated'] = 'Δημιουργήθηκε';
$string['detailview'] = 'Εμφάνιση λεπτομερειών';
$string['dimensions'] = 'Διαστάσεις';
$string['displayasdetails'] = 'Εμφάνιση ως λεπτομέρειες αρχείου';
$string['displayasicons'] = 'Εμφάνιση ως εικόνες αρχείων';
$string['displayastree'] = 'Εμφάνιση ως δέντρο αρχείων';
$string['displaydetails'] = 'Εμφάνιση φακέλου με λεπτομέρειες αρχείου';
$string['displayicons'] = 'Εμφάνιση φακέλου με εικόνες αρχείων';
$string['displaytree'] = 'Εμφάνιση φακέλου ως δέντρο αρχείων';
$string['downloadallfiles'] = 'Λήψη όλων των αρχείων';
$string['draftareanofiles'] = 'Δεν μπορεί να ληφθεί, επειδή δεν υπάρχουν συνημμένα αρχεία';
$string['emptylist'] = 'Άδεια λίστα';
$string['enter'] = 'Εισαγωγή';
$string['enternewname'] = 'Σας παρακαλώ, εισάγετε το νέο όνομα αρχείου';
$string['errordoublereference'] = 'Δεν είναι δυνατή η αντικατάσταση του αρχείου με μια συντόμευση / ψευδώνυμο διότι υπάρχουν ήδη συντομεύσεις προς αυτό το αρχείο.';
$string['errornotyourfile'] = 'Δεν μπορείτε να επιλέξετε ένα αρχείο που δεν έχει προστεθεί από εσάς';
$string['errorpostmaxsize'] = 'Το αρχείο που φορτώθηκε μπορεί να υπερβαίνει την οδηγία post_max_size στο php.ini.';
$string['erroruniquename'] = 'Το όνομα του αποθετηρίου πρέπει να είναι μοναδικό';
$string['errorwhilecommunicatingwith'] = 'Παρουσιάστηκε σφάλμα κατά την επικοινωνία με το αποθετήριο \'{$a}\'.';
$string['errorwhiledownload'] = 'Παρουσιάστηκε σφάλμα κατά τη λήψη του αρχείου: {$a}';
$string['fileexists'] = 'Το όνομα του αρχείου χρησιμοποιείται ήδη, παρακαλώ χρησιμοποιήστε ένα άλλο όνομα';
$string['fileexistsdialogheader'] = 'To αρχείο υπάρχει ήδη';
$string['fileexistsdialog_editor'] = 'Ένα αρχείο με αυτό το όνομα έχει ήδη επισυναφθεί στο κείμενο που επεξεργάζεστε.';
$string['fileexistsdialog_filemanager'] = 'Ένα αρχείο με αυτό το όνομα έχει ήδη επισυναφθεί';
$string['filesizenull'] = 'Το μέγεθος του αρχείου δεν μπορεί να προσδιοριστεί';
$string['folderexists'] = 'Το όνομα του αρχείου χρησιμοποιείτε ήδη, παρακαλώ χρησιμοποιήστε άλλο όνομα';
$string['foldernotfound'] = 'Δεν βρέθηκε ο φάκελος';
$string['folderrecurse'] = 'Ο φάκελος δεν μπορεί να μετακινηθεί σε υπό-φάκελο του';
$string['getfiletimeout'] = 'Πάρτε χρονικό όριο αρχείου';
$string['help'] = 'Βοήθεια';
$string['hidden'] = 'Κρυφό';
$string['imagesize'] = '{$a->width} x {$a->height} px';
$string['invalidfiletype'] = '{$a} τύπος αρχείου δεν είναι αποδεκτός.';
$string['invalidparams'] = 'Μη έγκυροι παράμετροι';
$string['lastmodified'] = 'Τελευταία τροποποίηση';
$string['license'] = 'Άδεια';
$string['linkexternal'] = 'Εξωτερικός σύνδεσμος';
$string['lostsource'] = 'Σφάλμα. Λείπει η πηγή. {$a}';
$string['makefileinternal'] = 'Δημιουργήστε ένα αντίγραφο του αρχείου';
$string['makefilelink'] = 'Σύνδεση με το αρχείο απευθείας';
$string['makefilereference'] = 'Δημιουργήστε ένα ψευδώνυμο / συντόμευση για το αρχείο';
$string['manageinstances'] = 'Διαχείριση στιγμιότυπου';
$string['moving'] = 'Μεταφορά';
$string['name'] = 'Όνομα';
$string['newfolder'] = 'Νέος φάκελος';
$string['newfoldername'] = 'Όνομα νέου φακέλου';
$string['nomorefiles'] = 'Δεν επιτρέπονται άλλα επισυναπτόμενα αρχεία';
$string['nopathselected'] = 'Δεν έχει επιλέξει  τη διαδρομή προορισμού ακόμη (κάντε διπλό κλικ σε ένα κόμβο του δέντρου για να επιλέξετε)';
$string['norepositoriesavailable'] = 'Δυστυχώς, κανένα από τα τρέχοντα αποθετήρια σας δεν μπορεί να επιστρέψει τα αρχεία στην απαιτούμενη μορφή.';
$string['norepositoriesexternalavailable'] = 'Δυστυχώς, κανένα από τα τρέχοντα αποθετήρια σας δεν μπορεί να επιστρέψει εξωτερικά αρχεία.';
$string['original'] = 'Αυθεντικό';
$string['overwrite'] = 'Αντικατάσταση';
$string['overwriteall'] = 'Αντικατάσταση όλων';
$string['path'] = 'Διαδρομή';
$string['pluginerror'] = 'Υπάρχει σφάλμα στο αποθετήριο των πρόσθετων.';
$string['popupblockeddownload'] = 'Το παράθυρο λήψης έχει αποκλειστεί, παρακαλώ επιτρέψτε το αναδυόμενο παράθυρο, και δοκιμάστε ξανά.';
$string['privatefilesof'] = '{$a} Προσωπικά αρχεία';
$string['referencesexist'] = 'Υπάρχουν {$a} ψευδώνυμα / συντομεύσεις που χρησιμοποιούν αυτό το αρχείο ως πηγή τους';
$string['referenceslist'] = 'Ψευδώνυμα / Συντομεύσεις';
$string['refreshnonjsfilepicker'] = 'Παρακαλώ κλείστε αυτό το παράθυρο και ανανεώστε τον μη javascript επιλογέα αρχείων';
$string['renameall'] = 'Μετονομασία όλων';
$string['renameto'] = 'Μετονομασία σε "{$a}"';
$string['repositoryerror'] = 'Το απομακρυσμένο αποθετήριο επέστρεψε σφάλμα: {$a}';
$string['repositoryicon'] = 'Εικονίδιο αποθετηρίου';
$string['searchrepo'] = 'Αναζήτηση αποθετηρίου';
$string['sectionbackup'] = 'Αντίγραφα ασφαλείας τμήματος';
$string['select'] = 'Επιλογή';
$string['setmainfile'] = 'Ορισμός κύριου αρχείου';
$string['setmainfile_help'] = 'Εάν υπάρχουν πολλά αρχεία στο φάκελο, το κύριο αρχείο είναι αυτό που εμφανίζεται στη σελίδα προβολής. Άλλα αρχεία, όπως εικόνες ή βίντεο μπορεί να είναι ενσωματωμένα σε αυτό. Στο διαχειριστή αρχείων το κύριο αρχείο υποδεικνύεται από τον τίτλο του ο οποίος είναι με έντονους χαρακτήρες.';
$string['syncfiletimeout'] = 'Χρονικό όριο συγχρονισμού αρχείου';
$string['syncimagetimeout'] = 'Χρονικό όριο συγχρονισμού εικόνας';
$string['type'] = 'Τύπος';
$string['undisclosedreference'] = '(Απόρρητες)';
$string['undisclosedsource'] = '(Απόρρητες)';
$string['unknownoriginal'] = 'Άγνωστες';
$string['unzipped'] = 'Αποσυμπιέστηκε επιτυχώς';
$string['uploadsucc'] = 'Το αρχείο έχει ανέβει επιτυχώς';
$string['uselatestfile'] = 'Χρήση τελευταίου αρχείου';
$string['usenonjsfilemanager'] = 'Άνοιγμα του διαχειριστή αρχείων σε νέο παράθυρο';
$string['usenonjsfilepicker'] = 'Άνοιγμα του επιλογέα αρχείων σε νέο παράθυρο';
$string['usercontextrepositorydisabled'] = 'Δεν μπορείτε να επεξεργαστείτε αυτό το αποθετήριο στο περιβάλλον χρήστη';
$string['xhtmlerror'] = 'Χρησιμοποιείτε πιθανώς μια XHTML strict header. Ορισμένα YUI στοιχεία δεν λειτουργούν με αυτή τη ρύθμιση, παρακαλούμε να το απενεργοποιήσετε.';
$string['ziped'] = 'Ο φάκελος συμπιέστηκε επιτυχώς';
