<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage plugin
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actions'] = 'Ενέργειες';
$string['checkforupdates'] = 'Έλεγχος για διαθέσιμες ενημερώσεις';
$string['checkforupdateslast'] = 'Τελευταίος έλεγχος στις {$a}';
$string['dependencyinstall'] = 'Εγκατάσταση';
$string['dependencyupload'] = 'Μεταφόρτωση';
$string['detectedmisplacedplugin'] = 'Το πρόσθετο "{$a->component}" είναι εγκατεστημένο σε λανθασμένη τοποθεσία "{$a->current}", η αναμενόμενη τοποθεσία είναι "{$a->expected}"';
$string['err_response_curl'] = 'Δεν είναι δυνατή η ανάκτηση διαθέσιμων ενημερώσεων - μη αναμενόμενο σφάλμα cURL.';
$string['err_response_format_version'] = 'Μη αναμενόμενη έκδοση στη μορφοποίηση της απάντησης. Παρακαλώ προσπαθήστε να ελέγξτε πάλι για διαθέσιμες ενημερώσεις.';
$string['err_response_http_code'] = 'Δεν είναι δυνατή η ανάκτηση διαθέσιμων ενημερώσεων - απρόσμενος κωδικός απόκρισης HTTP.';
$string['filterall'] = 'Εμφάνιση όλων';
$string['filtercontribonly'] = 'Εμφάνιση μόνο επιπλέον πρόσθετων';
$string['filtercontribonlyactive'] = 'Εμφάνιση μόνο επιπλέον πρόσθετων';
$string['filterupdatesonly'] = 'Εμφάνιση ανανεώσιμων μόνο';
$string['filterupdatesonlyactive'] = 'Εμφάνιση ανανεώσιμων μόνο';
$string['moodleversion'] = 'Moodle {$a}';
$string['nonehighlighted'] = 'Δεν υπάρχουν πρόσθετα που απαιτούν την προσοχή σας τώρα';
$string['nonehighlightedinfo'] = 'Εμφάνιση της λίστας όλων των εγκατεστημένων plugins ούτως ή άλλως';
$string['notdownloadable'] = 'Δεν είναι δυνατή η λήψη του πακέτου';
$string['notdownloadable_help'] = 'Το zip πακέτο με την ενημερωμένη έκδοση δεν μπορεί να κατέβει αυτόματα. Παρακαλούμε ανατρέξτε στη σελίδα τεκμηρίωσης του για περισσότερη βοήθεια.';
$string['notes'] = 'Σημειώσεις';
$string['notwritable'] = 'Τα αρχεία πρόσθετου δεν είναι εγγράψιμα';
$string['notwritable_help'] = 'Έχετε ενεργοποιήσει την αυτόματη εγκατάσταση ενημερώσεων και υπάρχει διαθέσιμη ενημέρωση για το αυτό το πρόσθετο. Όμως, τα αρχεία του πρόσθετου δεν είναι εγγράψιμα από τον web server, οπότε η ενημέρωση δεν μπορεί να εγκατασταθεί αυτόματα. Πρέπει να γίνει ο φάκελος του πρόσθετου και τα περιεχόμενα του εγγράψιμα ώστε να μπορεί να εγκατασταθεί η ενημέρωση αυτόματα.';
$string['numdisabled'] = 'Απενεργοποιημένο: {$a}';
$string['numextension'] = 'Επιπλέον: {$a}';
$string['numtotal'] = 'Εγκατεστημένα: {$a}';
$string['numupdatable'] = 'Διαθέσιμες ενημερώσεις: {$a}';
$string['otherplugin'] = '{$a->component}';
$string['otherpluginversion'] = '{$a->component} ({$a->version})';
$string['pluginchecknotice'] = 'Σε αυτή τη σελίδα εμφανίζονται τα πρόσθετα που μπορεί να χρειάζονται την προσοχή σας κατά την αναβάθμιση. Τα τονισμένα στοιχεία είναι: νέα πρόσθετα τα οποία θα εγκατασταθούν, ενημερωμένα πρόσθετα που θα αναβαθμιστούν και απόντα πρόσθετα. Τα επιπλέον πρόσθετα είναι τονισμένα εάν υπάρχει κάποια διαθέσιμη ενημέρωσή τους. Προτείνουμε να ελέγξετε εάν υπάρχουν πιο πρόσφατες εκδόσεις των πρόσθετων και να ενημερώσετε τον πηγαίο τους κώδικα πριν συνεχίσετε με την αναβάθμιση του Moodle.';
$string['plugindisable'] = 'Απενεργοποίηση';
$string['pluginenable'] = 'Ενεργοποίηση';
$string['release'] = 'Αποδέσμευση';
$string['requiredby'] = 'Απαιτείται από: {$a}';
$string['requires'] = 'Απαιτεί';
$string['rootdir'] = 'Κατάλογος';
$string['showall'] = 'Επαναφόρτωση και εμφάνιση όλων των πρόσθετων';
$string['somehighlighted'] = 'Ο αριθμός των πρόσθετων που απαιτεί την προσοχή σας είναι {$a}';
$string['somehighlightedinfo'] = 'Εμφάνιση της πλήρης λίστας των εγκατεστημένων πρόσθετων';
$string['somehighlightedonly'] = 'Εμφάνιση μόνο των πρόσθετων που απαιτούν την προσοχή σας';
$string['sourceext'] = 'Επιπλέον';
$string['status_delete'] = 'Προς διαγραφή';
$string['status_downgrade'] = 'Υπάρχει εγκατεστημένη πιο πρόσφατη έκδοση!';
$string['status_new'] = 'Προς εγκατάσταση';
$string['status_upgrade'] = 'Προς αναβάθμιση';
$string['status_uptodate'] = 'Εγκατεστημένα';
$string['type_auth'] = 'Μέθοδος ταυτοποίησης';
$string['type_availability'] = 'Περιορισμός διαθεσιμότητας';
$string['type_availability_plural'] = 'Περιορισμός διαθεσιμοτήτων';
$string['type_cachelock'] = 'Διαχειριστής κλειδώματος cache';
$string['type_cachelock_plural'] = 'Διαχειριστές κλειδώματος cache';
$string['type_cachestore'] = 'Αποθήκη cache';
$string['type_cachestore_plural'] = 'Αποθήκες cache';
$string['type_calendartype'] = 'Τύπος ημερολογίου';
$string['type_calendartype_plural'] = 'Τύποι ημερολογίου';
$string['type_coursereport'] = 'Αναφορά μαθήματος';
$string['type_editor'] = 'Συντάκτης';
$string['type_enrol'] = 'Μέθοδος εγγραφής';
$string['type_format'] = 'Τύπος μαθήματος';
$string['type_gradeexport'] = 'Μέθοδος εξαγωγής βαθμών';
$string['type_gradeimport'] = 'Μέθοδος εισαγωγής βαθμών';
$string['type_gradereport'] = 'Αναφορά βιβλίου βαθμολογιών';
$string['type_gradingform'] = 'Προχωρημένη μέθοδος βαθμολόγησης';
$string['type_gradingform_plural'] = 'Προχωρημένες μέθοδοι βαθμολόγησης';
$string['type_local'] = 'Τοπικό πρόσθετο';
$string['type_message'] = 'Μήνυμα εξόδου';
$string['type_message_plural'] = 'Μηνύματα εξόδου';
$string['type_mnetservice'] = 'Mnet υπηρεσία';
$string['type_plagiarism'] = 'Πρόσθετο πρόληψης λογοκλοπής';
$string['type_profilefield'] = 'Τύπου πεδίου προφίλ';
$string['type_qbehaviour'] = 'Ερώτηση συμπεριφοράς';
$string['type_qbehaviour_plural'] = 'Ερωτήσεις συμπεριφοράς';
$string['type_qformat'] = 'Μορφή εισαγωγής / εξαγωγής ερωτήσεων';
$string['type_report'] = 'Αναφορά ιστοχώρου';
$string['type_tool'] = 'Διαχειριστικό εργαλείο';
$string['type_tool_plural'] = 'Διαχειριστικά εργαλεία';
$string['type_webservice'] = 'Πρωτόκολλο Webservice';
$string['uninstallconfirm'] = 'Πρόκειται να απεγκαταστήσετε το πρόσθετο <em>{$a->name}</em>. Αυτό θα έχει σαν αποτέλεσμα να διαγραφούν πλήρως όλα τα στοιχεία στη βάση δεδομένων που σχετίζονται με αυτό το πρόσθετο, συμπεριλαμβανομένων των ρυθμίσεών του, των αρχείων καταγραφής του, τα αρχεία χρηστών που διαχειρίζονται από το πρόσθετο κτλ. Δεν υπάρχει επιστροφή και το ίδιο το Moodle δεν δημιουργεί αντίγραφο ασφαλείας. Είστε ΣΙΓΟΥΡΟΙ ότι θέλετε να συνεχίσετε;';
$string['uninstalldelete'] = 'Όλα τα δεδομένα που σχετίζονται με το πρόσθετο <em>{$a->name}</em> έχουν διαγραφεί από τη βάση δεδομένων. Προκειμένου να μην εγκατασταθεί ξανά το πρόσθετο, ο φάκελός του <em>{$a->rootdir}</em> πρέπει να διαγραφεί χειροκίνητα από τον διακομιστή άμεσα. Το Moodle δεν μπορεί να σβήσει τον φάκελο λόγω δικαιωμάτων.';
$string['uninstalldeleteconfirm'] = 'Όλα τα δεδομένα που σχετίζονται με το πρόσθετο <em>{$a->name}</em> έχουν διαγραφεί από τη βάση δεδομένων. Προκειμένου να μην εγκατασταθεί ξανά το πρόσθετο, ο φάκελός του <em>{$a->rootdir}</em> πρέπει να διαγραφεί χειροκίνητα από τον διακομιστή άμεσα. Θέλετε να διαγράψετε τον φάκελο τώρα;';
$string['uninstalldeleteconfirmexternal'] = 'Φαίνεται πως το συγκεκριμένο πρόσθετο έχει ληφθεί μέσω του συστήματος διαχείρισης πηγαίου κώδικα ({$a}). Εάν διαγράψετε τον φάκελο του πρόσθετου μπορεί να χάσετε σημαντικές τοπικές τροποποιήσεις του κώδικα. Παρακαλώ βεβαιωθείτε ότι θέλετε να σβήσετε τον φάκελο πριν συνεχίσετε.';
$string['uninstallextraconfirmblock'] = 'Υπάρχουν {$a->instances} εμφανίσεις αυτού του μπλοκ.';
$string['uninstallextraconfirmenrol'] = 'Υπάρχουν {$a->enrolments} εγγραφές χρηστών.';
$string['uninstallextraconfirmmod'] = 'Υπάρχουν {$a->instances} εμφανίσεις αυτής της  ενότητας σε {$a->courses} μαθήματα.';
$string['uninstalling'] = 'Απεγκατάσταση {$a->name}';
$string['updateavailable'] = 'Υπάρχει νέα έκδοση {$a} διαθέσιμη!';
$string['updateavailable_moreinfo'] = 'Περισσότερες πληροφορίες...';
$string['updateavailable_release'] = 'Release {$a}';
$string['updatepluginconfirm'] = 'Επιβεβαίωση ενημέρωσης πρόσθετου';
$string['updatepluginconfirmexternal'] = 'Φαίνεται πως η τρέχουσα έκδοση του πρόσθετου έχει ληφθεί μέσω του συστήματος διαχείρισης πηγαίου κώδικα ({$a}). Εάν απεγκαταστήσετε αυτή την ενημέρωση, δεν θα λαμβάνετε πλέον ενημερώσεις του πρόσθετου από το σύστημα διαχείρισης πηγαίου κώδικα. Παρακαλώ επιβεβαιώστε ότι θέλετε να ενημερώσετε το πρόσθετο πριν προχωρήσετε.';
$string['updatepluginconfirminfo'] = 'Πρόκειται να εγκαταστήσετε μια νέα έκδοση του πρόσθετου <strong>{$a->name}</strong>. Ένα αρχείο zip με έκδοση {$a->version} του πρόσθετου θα ληφθεί από το <a href="{$a->url}">{$a->url}</a> και θα αποσυμπιεστεί στη Moodle εγκατάστασή σας ώστε να ενημερώσει το πρόσθετο.';
$string['updatepluginconfirmwarning'] = 'Παρακαλώ θυμηθείτε ότι το Moodle δεν θα φτιάξει αντίγραφο ασφαλείας της βάσης δεδομένων πριν την αναβάθμιση. 
Σας συνιστούμε να κάνετε ένα πλήρες αντίγραφο ασφαλείας τώρα, για να αντιμετωπίσετε την σπάνια περίπτωση κατά την οποία ο νέος κώδικας έχει σφάλματα που θα κάνουν το site σας μη διαθέσιμο ή ακόμα και να χαλάσει τη βάση δεδομένων σας. Προχωρήστε με δική σας ευθύνη.';
$string['versiondb'] = 'Τρέχουσα έκδοση';
$string['versiondisk'] = 'Νέα έκδοση';
