<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage mnet
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allhosts'] = 'Όλοι οι κεντρικοί υπολογιστές';
$string['allhosts_no_options'] = 'Δεν υπάρχουν διαθέσιμες επιλογές κατά την προβολή πολλαπλών κεντρικών υπολογιστών';
$string['applicationtype'] = 'Τύπος εφαρμογής';
$string['deletedhostinfo'] = 'Αυτός ο κεντρικός υπολογιστής έχει διαγραφεί. Εάν θέλετε να τον επαναφέρετε, αλλάξτε την διαγραμμένη κατάσταση σε \'Όχι\'.';
$string['deletedhosts'] = 'Διαγραμμένοι κεντρικοί υπολογιστές: {$a}';
$string['eventaccesscontrolcreated'] = 'Δημιουργήθηκε έλεγχος πρόσβασης';
$string['eventaccesscontrolupdated'] = 'Ενημερώθηκε ο έλεγχος πρόσβασης';
$string['exportfields'] = 'Πεδία για εξαγωγή';
$string['findlogin'] = 'Εύρεση login';
$string['hostlist'] = 'Λίστα με κεντρικούς υπολογιστές δικτύου';
$string['inspect'] = 'Επιθεώρηση';
$string['installnosuchfunction'] = 'Προγραμματιστικό λάθος! Κάτι προσπαθεί να εγκαταστήσει τη mnet xmlrpc ρουτίνα ({$a->method}) από το αρχείο ({$a->file}) και δεν τη βρίσκει!';
$string['installnosuchmethod'] = 'Προγραμματιστικό λάθος! Κάτι προσπαθεί να εγκαταστήσει τη mnet xmlrpc μέθοδο ({$a->method}) στη κλάση ({$a->file}) και δεν τη βρίσκει!';
$string['installreflectionclasserror'] = 'Προγραμματιστικό λάθος! Η MNet introspection απέτυχε για τη μέθοδο \'{$a->method}\' στην κλάση class \'{$a->class}\'. Το αρχικό μήνυμα λάθους, σε περίπτωση που βοηθάει, είναι: \'{$a->error}\'';
$string['installreflectionfunctionerror'] = 'Προγραμματιστικό λάθος! Η MNet introspection απέτυχε για τη ρουτίνα \'{$a->method}\' στο αρχείο \'{$a->file}\'. Το αρχικό μήνυμα λάθους, σε περίπτωση που βοηθάει, είναι: \'{$a->error}\'';
$string['leavedefault'] = 'Χρήση των προεπιλεγμένων μηνυμάτων';
$string['listservices'] = 'Λίστα υπηρεσιών';
$string['managemnetpeers'] = 'Διαχείριση ομοίων';
$string['method'] = 'Μέθοδος';
$string['methodhelp'] = 'Βοήθεια για τη μέθοδο {$a}';
$string['methodsavailableonhost'] = 'Μέθοδοι διαθέσιμοι σε {$a}';
$string['methodsavailableonhostinservice'] = 'Μέθοδοι διαθέσιμοι για {$a->service} σε {$a->host}';
$string['methodsignature'] = 'Υπογραφή μεθόδου για {$a}';
$string['mnetidprovider'] = 'Πάροχος MNet ID';
$string['mnetidproviderdesc'] = 'Μπορείτε να χρησιμοποιήσετε αυτή τη λειτουργία για να ανακτήσετε ένα σύνδεσμο με τη βοήθεια του οποίου θα μπορέσετε να  κάνετε login, εφόσον δώσετε τη σωστή διεύθυνση ηλεκτρονικού ταχυδρομείο. Η διεύθυνση αυτή θα πρέπει να ταιριάζει με το όνομα πρόσβασης που χρησιμοποιήσατε για να κάνετε login.';
$string['mnetidprovidermsg'] = 'Μπορείτε να κάνετε login στον {$a} πάροχο.';
$string['mnetidprovidernotfound'] = 'Λυπούμαστε, αλλά δεν βρέθηκαν περαιτέρω πληροφορίες';
$string['noaddressforhost'] = 'Λυπούμαστε, αλλά το όνομα του κεντρικού υπολογιστή ({$a}) δεν βρέθηκε!';
$string['notenoughidpinfo'] = 'Ο πάροχός σας δεν παρέχει αρκετά στοιχεία ώστε να δημιουργηθεί ή να ενημερωθεί ο λογαριασμός σας τοπικά. Συγγνώμη!';
$string['notinxmlrpcserver'] = 'Προσπάθεια πρόσβασης στον MNet απομακρυσμένο υπολογιστή-πελάτη, όχι κατά τη διάρκεια της εκτέλεσης του server XMLRPC';
$string['notmoodleapplication'] = 'ΠΡΟΕΙΔΟΠΟΙΗΣΗ: Αυτή δεν είναι μια εφαρμογή Moodle, οπότε κάποιες από τις μεθόδους επιθεώρησης μπορεί να μην λειτουργούν σωστά.';
$string['notpermittedtojumpas'] = 'Δεν μπορείτε να ξεκινήσετε μια απομακρυσμένη σύνοδο, ενώ είστε συνδεδεμένοι ως άλλος χρήστης.';
$string['peerprofilefielddesc'] = 'Εδώ μπορείτε να παρακάμψετε τις γενικές ρυθμίσεις για το ποια πεδία προφίλ αποστέλλονται και εισάγονται όταν δημιουργούνται νέοι χρήστες';
$string['position'] = 'Θέση';
$string['publickeyrequired'] = 'Πρέπει να δώσετε ένα δημόσιο κλειδί.';
$string['registerhostsoff'] = 'Η εγγραφή όλων των κεντρικών υπολογιστών είναι <b>απενεργοποιημένη</b>';
$string['registerhostson'] = 'Η εγγραφή όλων των κεντρικών υπολογιστών είναι <b>ενεργοποιημένη</b>';
$string['remoteuser'] = 'Απομακρυσμένος {$a->remotetype} χρήστης';
$string['remoteuserinfo'] = 'Το προφίλ ανακτήθηκε από <a href="{$a->remoteurl}">{$a->remotename}</a>';
$string['returnvalue'] = 'Επιστρεφόμενη τιμή';
$string['service'] = 'Όνομα υπηρεσίας';
$string['serviceid'] = 'Κωδικός υπηρεσίας';
$string['servicesavailableonhost'] = 'Οι υπηρεσίες είναι διαθέσιμες στο {$a}';
$string['sslverification'] = 'Επαλήθευση SSL';
$string['sslverification_help'] = 'Αυτή η επιλογή σας επιτρέπει να ρυθμίσετε το επίπεδο ασφαλείας όταν συνδέεστε σε άλλο υπολογιστή με HTTPS. * Κανένα: κανένα επίπεδο ασφάλειας * Επιβεβαίωση κεντρικού υπολογιστή μόνο: επικυρώνει τον τομέα του πιστοποιητικού SSL * Επιβεβαίωση κεντρικού υπολογιστή και υπολογιστή (συνιστάται): επικυρώνει τον τομέα και τον εκδότη του πιστοποιητικού SSL';
$string['testclient'] = 'δοκιμαστικός υπολογιστής MNet';
$string['theypublish'] = 'Δημοσιεύουν';
$string['theysubscribe'] = 'Εγγράφονται';
$string['turnitoff'] = 'Κλείστο';
$string['turniton'] = 'Άνοιξε το';
$string['type'] = 'Τύπος';
$string['unknown'] = 'Άγνωστο';
$string['usernotfullysetup'] = 'Ο λογαριασμός σας είναι ημιτελής. Χρειάζεται να πάτε <a href="{$a}">στον πάροχό σας</a> και να διασφαλίσετε ότι το προφίλ σας είναι πλήρες. Μπορεί να χρειαστεί να αποσυνδεθείτε και να συνδεθείτε ξανά για να εμφανιστούν οι αλλαγές.';
$string['verifyhostandpeer'] = 'Επιβεβαιώστε τον κεντρικό υπολογιστή και τον υπολογιστή';
$string['verifyhostonly'] = 'Επιβεβαιώστε μόνο τον κεντρικό υπολογιστή';
