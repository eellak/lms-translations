<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle.test.noc.ntua.gr
 *
 * @package    core
 * @subpackage pagetype
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['page-admin-current'] = 'Η τρέχουσα σελίδα διαχείρισης';
$string['page-admin-x'] = 'Όλες οι σελίδες διαχείρισης';
$string['page-course-index'] = 'Σελίδας προβολής αρχικής κατηγορίας';
$string['page-course-index-category'] = 'Σελίδας προβολής τρέχουσας κατηγορίας';
$string['page-course-index-x'] = 'Όλες οι σελίδες προβολής κατηγοριών';
$string['page-course-report-x'] = 'Όλες οι αναφορές μαθημάτων';
$string['page-course-search'] = 'Σελίδα αναζήτησης μαθημάτων';
$string['page-course-view-x'] = 'Αρχική σελίδα όλων των τύπων μαθημάτων';
$string['page-course-x'] = 'Όλες οι σελίδες μαθημάτων';
$string['page-mod-x'] = 'Όλες οι σελίδες δραστηριοτήτων της ενότητας';
$string['page-mod-x-view'] = 'Όλες οι σελίδες κυρίων δραστηριοτήτων της ενότητας';
$string['page-report-x'] = 'Όλες οι σελίδες αναφορών';
$string['page-site-index'] = 'Μόνο η αρχική σελίδα';
$string['page-site-x'] = 'Όλες οι σελίδες ιστοχώρων ανώτατου επιπέδου';
$string['page-user-profile'] = 'Μόνο σελίδες προφίλ χρηστών';
$string['page-user-view'] = 'Μόνο σελίδες προφίλ χρηστών';
$string['page-user-x'] = 'Όλες οι σελίδες χρηστών';
$string['page-x'] = 'Όλες οι σελίδες';

